<!DOCTYPE html>
<html
    lang="en"
    class="light-style customizer-hide"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free"
>
<head>
    <meta charset="utf-8" />
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title><?php echo $data['tag_page'] ?></title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon"  href="<?php echo media()?>/img/iconoMacrogram.png" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
        rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="<?php echo media()?>/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="<?php echo media()?>/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="<?php echo media()?>/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="<?php echo media()?>/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?php echo media()?>/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->
    <!-- Page -->
    <link rel="stylesheet" href="<?php echo media()?>/vendor/css/pages/page-auth.css" />
    <!-- Helpers -->
    <script src="<?php echo media()?>/vendor/js/helpers.js"></script>
    <script src="<?php echo media()?>/js/config.js"></script>
</head>

<body>
<!-- Content -->

<div class="container-xxl">
    <div class="authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner">
            <!-- Register Card -->
            <div class="card " >
                <div class="card-body">
                    <!-- Logo -->
                    <div class="app-brand justify-content-center">
                        <img class="app-brand-link gap-2" width="50%" src="<?php echo media()?>/img/logoMacrogram2.png">
                    </div>
                    <!-- /Logo -->

                    <p class="mb-4">Registro de Nuevos Usuarios</p>

                    <form id="formAuthentication" class="mb-6" action="<?php echo base_url()?>registro/create" method="POST">
                       <div class="row">
                            <div class="col-md-6">
                                <label for="nombres" class="form-label">Nombres</label>
                                <input
                                        type="text"
                                        class="form-control"
                                        id="nombres"
                                        name="nombres"
                                        placeholder="Ingrese sus Nombres"
                                        autofocus
                                />
                            </div>
                           <div class="col-md-6">
                               <label for="apellidos" class="form-label">Apellidos</label>
                               <input
                                       type="text"
                                       class="form-control"
                                       id="apellidos"
                                       name="apellidos"
                                       placeholder="Ingrese sus Apellidos"
                                       autofocus
                               />
                           </div>
                           <div class="col-md-6">
                               <label for="username" class="form-label">Username</label>
                               <input
                                       type="text"
                                       class="form-control"
                                       id="username"
                                       name="username"
                                       placeholder="Ingrese su Username"
                                       autofocus
                               />
                           </div>
                           <div class="col-md-6 form-password-toggle">
                               <label class="form-label" for="password">Contraseña</label>
                               <div class="input-group input-group-merge">
                                   <input
                                           type="password"
                                           id="password"
                                           class="form-control"
                                           name="password"
                                           placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                           aria-describedby="password"
                                   />
                                   <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
                           </div>

                       </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Correo</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Ingrese su Correo Electronico" />
                        </div>


                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="terms-conditions" name="terms" />
                                <label class="form-check-label" for="terms-conditions">
                                    Acepto la
                                    <a href="javascript:void(0);">terminos y politicas de la empresa. </a>
                                </label>
                            </div>
                        </div>
                        <button type="submit"  id="btn-enviar" class="btn btn-primary d-grid w-100" disabled>Crear Cuenta</button>
                    </form>

                    <p class="text-center">
                        <span>Ya dispones de una cuenta?</span>
                        <a href="<?=base_url()?>login">
                            <span>Inicia Sesión aqui</span>
                        </a>
                    </p>
                </div>
            </div>
            <!-- Register Card -->
        </div>
    </div>
</div>


<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="<?php echo media()?>/vendor/libs/jquery/jquery.js"></script>
<script src="<?php echo media()?>/vendor/libs/popper/popper.js"></script>
<script src="<?php echo media()?>/vendor/js/bootstrap.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo media()?>/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

<script src="<?php echo media()?>/vendor/js/menu.js"></script>
<!-- endbuild -->

<!-- Vendors JS -->

<!-- Main JS -->
<script src="<?php echo media()?>/js/main.js"></script>

<!-- Page JS -->
<script src="<?php echo media()?>/js/web/registro.js"></script>
<!-- Place this tag in your head or just before your close body tag. -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
</body>
</html>
