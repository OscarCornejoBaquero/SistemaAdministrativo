var tableEstablecimientos;
function requestAll(){
    return  request = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
}
document.addEventListener('DOMContentLoaded', function(){
    var idEmpresa = $('#idEmpresa').val();
    tableEstablecimientos = $('#tableEstablecimientos').DataTable( {
        "aProcessing":true,
        "aServerSide":true,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
        },
        "ajax":{
            "url": " "+base_url+"establecimiento/getSucursalesEmpresas/"+idEmpresa,
            "dataSrc":""
        },
        "columns":[
            {"data":"id_sucursal"},
            {"data":"nombre_comerial_empresa"},
            {"data":"nombre_sucursal"},
            {"data":"codigo_sucursal"},
            {"data":"estadoSucursal"},
            {"data":"acciones"},
            {"data":"options"}
        ],
        'dom': 'Bfrtip',

        'buttons': [
            {
                "extend": "copyHtml5",
                "text": "<i class='far fa-copy'></i> Copiar",
                "titleAttr":"Copiar",
                "className": "btn btn-secondary"
            },{
                "extend": "excelHtml5",
                "text": "<i class='fas fa-file-excel'></i> Excel",
                "titleAttr":"Esportar a Excel",
                "className": "btn btn-success"
            },{
                "extend": "pdfHtml5",
                "text": "<i class='fas fa-file-pdf'></i> PDF",
                "titleAttr":"Esportar a PDF",
                "className": "btn btn-danger"
            }
        ],
        "resonsieve":"true",
        "bDestroy": true,
        "autoFill": true,
        "iDisplayLength": 10,
        "order":[[0,"acs"]]
    });

}, false);

function openModal(data)
{
    var ajaxUrl = base_url+'establecimiento/getInfoEstablecimiento/'+data;
    $.ajax({
        type: 'get',
        url: ajaxUrl,
        data: data,
        cache:false,
        contentType: false,
        processData: false,
        beforeSend: function(){
        },
        complete:function(data){
        },
        success: function(data){
            var objData = JSON.parse(data);
            var data = objData.data;
            console.log(data);
            $('#titleEstablecimiento').text("Establecimiento"+" "+data['nombre_sucursal']);
            $('#id_establecimiento').val(data['id_sucursal']);
            $('#nombre_comerial_empresa').text(data['nombre_comerial_empresa']);
            $('#codigo_sucursal').text(data['codigo_sucursal']);
            $('#nombre_sucursal').text(data['nombre_sucursal']);
            $('#direccion_sucursal').text(data['direccion_sucursal']);
            $('#nombre_comercial_sucursal').text(data['nombre_comercial_sucursal']);

            if(data['logo_sucursal'] == null || data['logo_sucursal'] == "null"){
                $('#logo_sucursal').prop('src',base_url+'Assets/img/empresas/sucursales/logos/default.jpg');
            }else{
                $('#logo_sucursal').prop('src',base_url+'Assets/img/empresas/sucursales/logos/'+data['logo_sucursal']);
            }
            $('#modalEstablecimiento').modal('show');
        },
        error: function(data){
            Swal.fire({
                title: 'Error',
                text: 'Problemas al procesar la consulta',
                icon: 'error',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
            }).then((result) => {
                location.reload();
            })
        }
    });

}
function editarEstablecimiento(){
    idEstablecimiento = $('#id_establecimiento').val();
    console.log(idEstablecimiento);
    window.location.href = '../../establecimiento/editarEstablecimiento/'+idEstablecimiento;
}
function addImage(e) {
    var file = e.target.files[0],
        imageType = /image.*/;
    if (!file.type.match(imageType)) {
        Swal.fire('Hey', 'El formato no es el correcto', 'warning');
    } else {
        var reader = new FileReader();
        reader.onload = fileOnload;
        reader.readAsDataURL(file);
        return;
    }
}
function fileOnload(e) {
    var result = e.target.result;
    $('#uploadLogo').attr("src", result);
}
$('#upload').change(function(e) {
    previa = "uploadLogo";
    addImage(e);
});
$(document).ready(function () {
    $("#formCrearEstablecimiento").bind("submit", function (e) {
        /* if (validarRegistro()) {
             e.preventDefault();
             Swal.fire({
                 title: 'Error en datos del Usuario ',
                 text: 'Debe de Ingresar datos para el registro',
                 icon: 'error',
                 showCancelButton: false,
                 confirmButtonColor: '#3085d6',
             }).then((result) => {
                 location.reload();
             })
        // } else {*/
        // Capturamnos el boton de envío
        var btnEnviar = $("#btn-enviar");
        var idEmpresa =$('#id_empresa').val();
        var formData = new FormData(this);
        console.log(formData);
        $.ajax({
            type: $(this).attr("method"),
            url: $(this).attr("action"),
            // data:$(this).serialize(),
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            beforeSend: function () {
                /*
                * Esta función se ejecuta durante el envió de la petición al
                * servidor.
                * */
                btnEnviar.val("Enviando"); // Para input de tipo button
                btnEnviar.attr("disabled", "disabled");
            },
            complete: function (data) {
                /*
                * Se ejecuta al termino de la petición
                * */
                btnEnviar.val("Almacenando Empresa");
                btnEnviar.removeAttr("disabled");
            },
            success: function (data) {
                /*
                * Se ejecuta cuando termina la petición y esta ha sido
                * correcta
                * */
                var objData = JSON.parse(data);
                var respuesta = objData.msg;
                var title = objData.title;
                var icon = objData.icon;
                console.log(objData);
                Swal.fire({
                    title: title,
                    text: respuesta,
                    icon: icon,
                    showCancelButton: false,
                    confirmButtonColor: '#3085d6',
                }).then((result) => {
                    if (title != "Error") {
                        window.location.href = '../../establecimiento/establecimientosEmpresas/'+idEmpresa;
                    } else {
                        location.reload();
                    }

                })
            },
            error: function (data) {
                /*
                * Se ejecuta si la peticón ha sido erronea
                * */
                Swal.fire({
                    title: 'Error',
                    text: 'Problemas al tratar de enviar el formulario',
                    icon: 'error',
                    showCancelButton: false,
                    confirmButtonColor: '#3085d6',
                }).then((result) => {
                    location.reload();
                })
            }
        });
        // }
        // Nos permite cancelar el envio del formulario
        return false;
    });
});
function eliminar(id){
    var idEmpresa = $('#id_empresa').val();
    console.log(idEmpresa);
    Swal.fire({
        title: 'Esta Seguro que desea Eliminar el Establecimiento?',
        text: "Recuerde que esta Operación es Irreversible y afectara a los puntos de venta que tengas creado. ",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si Eliminar Establecimiento'
    }).then((result) => {
        if (result.isConfirmed) {
            var ajaxUrl = base_url+'establecimiento/eliminarEstablecimiento/'+id;
            $.ajax({
                type: 'get',
                url: ajaxUrl,
                data: id,
                cache: false,
                contentType: false,
                processData: false,
                success: function (data) {
                    /*
                    * Se ejecuta cuando termina la petición y esta ha sido
                    * correcta
                    * */
                    var objData = JSON.parse(data);
                    var respuesta = objData.msg;
                    var title = objData.title;
                    var icon = objData.icon;
                    console.log(objData);
                    Swal.fire({
                        title: title,
                        text: respuesta,
                        icon: icon,
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        if (title != "Error") {
                            window.location.href = '../../establecimiento/establecimientosEmpresas/'+idEmpresa;
                        } else {
                            location.reload();
                        }

                    })
                },
                error: function (data) {
                    /*
                    * Se ejecuta si la peticón ha sido erronea
                    * */
                    Swal.fire({
                        title: 'Error',
                        text: 'Problemas al tratar de eliminar la empresa.',
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        location.reload();
                    })
                }
            });

        }
    })
}