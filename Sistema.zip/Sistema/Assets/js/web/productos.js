$(document).ready(function() {
    $('.js-example-basic-single').select2(
        {
            width: '100%',
            placeholder: "Seleccionar"
        }
    );

});

var tableProductos;
function requestAll(){
    return  request = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
}
document.addEventListener('DOMContentLoaded', function(){
    tableProductos = $('#tableProductos').DataTable( {
        "aProcessing":true,
        "aServerSide":true,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
        },
        "ajax":{
            "url": " "+base_url+"productos/getDataTable",
            "dataSrc":""
        },
        "columns":[
            {"data":"id_producto"},
            {"data":"codigo_producto"},
            {"data":"nombre_categoria"},
            {"data":"stock_producto"},
            {"data":"precio_unitario"},
            {"data":"estadoProducto"},
            {"data":"options"}
        ],
        'dom': 'Bfrtip',

        'buttons': [
            {
                "extend": "copyHtml5",
                "text": "<i class='far fa-copy'></i> Copiar",
                "titleAttr":"Copiar",
                "className": "btn btn-secondary"
            },{
                "extend": "excelHtml5",
                "text": "<i class='fas fa-file-excel'></i> Excel",
                "titleAttr":"Exportar a Excel",
                "className": "btn btn-success"
            },{
                "extend": "pdfHtml5",
                "text": "<i class='fas fa-file-pdf'></i> PDF",
                "titleAttr":"Exportar a PDF",
                "messageTop": "Reporte General de Productos",
                "className": "btn btn-danger",
                "exportOptions": {
                    "columns": [ 1,2,3,4,5]
                }
            }
        ],
        "resonsieve":"true",
        "bDestroy": true,
        "autoFill": true,
        "iDisplayLength": 10,
        "order":[[0,"acs"]]
    });

}, false);

function buscarCategoria(){
    $('#modalCategoriasProductos').modal('show');
}
$(document).ready(function(){
    $("#categorias").change(function(){
        var id_categorias= $(this).children("option:selected").val();
        var categoria = $(this).children("option:selected").text();
        $('#categoriaSeleccionada').text(categoria);
        $('#idCategoria').val(id_categorias);
    });
});

$(document).ready(function () {
    $("#formCrearCategoria").bind("submit", function (e) {
        // Capturamnos el boton de envío
        if(validarCategoria() == true){

            var formData = new FormData(this);
            e.preventDefault();
            console.log(formData);
            $.ajax({
                type: $(this).attr("method"),
                url: $(this).attr("action"),
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function () {
                },
                complete: function (data) {
                },
                success: function (data) {

                    var objData = JSON.parse(data);
                    var respuesta = objData.msg;
                    var title = objData.title;
                    var icon = objData.icon;
                    console.log(objData);
                    Swal.fire({
                        title: title,
                        text: respuesta,
                        icon: icon,
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                        target: document.getElementById('modalCategoriasProductos'),
                    }).then((result) => {
                        if (title != "Error") {

                        } else {
                            $('#modalCategoriasProductos').modal('hidden');
                        }
                    })
                },
                error: function (data) {
                    Swal.fire({
                        title: 'Error',
                        text: 'Problemas al tratar de enviar el formulario',
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                        target: document.getElementById('modalCategoriasProductos'),
                    }).then((result) => {
                        location.reload();
                    })
                }
            });
            return false;
        }else{
            Swal.fire({
                title: 'Error',
                text: 'Debe de Rellenar los campos requeridos.',
                icon: 'error',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
                target: document.getElementById('modalCategoriasProductos'),
            }).then((result) => {

            })
            e.preventDefault();
        }
    });
});
function validarCategoria() {
    let nombre_categoria = $('#nombreCategoria').val();
    let descripcion_categoria = $('#descripcion').val();

    if(nombre_categoria != ""){

        if( descripcion_categoria != "" ){
            return true;
        }else{
            return false;
        }
    }else {
        return false;
    }
}