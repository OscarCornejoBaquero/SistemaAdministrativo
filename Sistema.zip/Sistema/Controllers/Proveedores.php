<?php
require_once("Models/NavModel.php");
require_once("Models/InformaciongeneralModel.php");
require_once ("Excepciones/ExProveedores.php");
require_once("Objetos/Empresa/Proveedor.php");
require_once("Models/Crud.php");

class Proveedores extends Controllers implements Crud
{
    private Proveedor $objProveedor;
    private ExProveedores $validaciones ;
    public function __construct()
    {
        session_start();
        if (empty($_SESSION['login'])) {
            header('Location: ' . base_url());
        }
        parent::__construct();
        $this->validaciones = new ExProveedores();
    }
    public function proveedores(){
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();
        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['tag_page'] = "Proveedores";
        $data['page_title'] = "Proveedor";
        $data['page_name'] = "Proveedor de las Empresas";
        $this->views->getView($this, "proveedores", $data);
    }

    public function getDataTable(){
        $arrData = $this->model->getDataTable();


        for ($i = 0; $i < sizeof($arrData); $i++) {

            $datos = $arrData[$i]['id_proveedor'];
            $arrData[$i]['id_proveedor'] = '<button class="btn p-0 dropdown-toggle hide-arrow" onclick="openModal(' . $datos . ');" title="Ver Información de la Empresa"><i class="menu-icon tf-icons bx bx-show"></i></button>';
            if ($arrData[$i]['estado'] == 1) {
                $arrData[$i]['estado'] = '<span class="badge badge-success" style="background: green">Activo</span>';
            } else {
                $arrData[$i]['estado'] = '<span class="badge badge-danger" style="background: red">Inactivo</span>';
            }

            $arrData[$i]['options'] = '
            <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu">
                                
                                <a class="dropdown-item" href="'.base_url().'proveedores/edit/'.$datos.'"
                                ><i class="bx bx-edit-alt me-1"></i> Editar</a
                                >
                                <a class="dropdown-item " href="#" onclick="eliminar('.$datos.');"
                                ><i class="bx bx-trash me-1"></i> Eliminar</a
                                >
                            </div>
                        </div>
            ';
        }

        echo json_encode($arrData, JSON_UNESCAPED_UNICODE);
        die();
    }
    public function show($id)
    {
        // TODO: Implement show() method.
        try {
            $respuesta = $this->model->show($id);
            $arrResponse = array('status' => true, 'msg' => 'OK',
                'title' => 'Correcto', 'icon' => 'success', 'data' => $respuesta);

        } catch (Exception $e) {
            $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' => 'error');
        }
        echo json_encode($arrResponse, JSON_UNESCAPED_UNICODE);
    }

    public function create()
    {
        // TODO: Implement create() method.
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();
        $provincias = new InformaciongeneralModel();
        $arrDataProvincias = $provincias->getProvincias();
        $data['provincias'] = $arrDataProvincias;
        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['tag_page'] = "Crear Proveedor";
        $data['page_title'] = "Crear Proveedor";
        $data['page_name'] = "Creación de Proveedor para las Empresas";
        $this->views->getView($this, "create", $data);
    }
    public function getCiudades($id_provincia){
        $informacion = new InformaciongeneralModel();
        $arrData = $informacion->getCiudades($id_provincia);
        echo json_encode($arrData, JSON_UNESCAPED_UNICODE);
        die();
    }

    public function store()
    {
        // TODO: Implement store() method.
        if($_POST){
            try {
                $this->objProveedor = new Proveedor();
                $this->objProveedor->setRazonSocial($_POST['fullname']);
                $this->objProveedor->setRuc($_POST['ruc']);
                $this->objProveedor->setEmail($_POST['email']);
                $this->objProveedor->setTelefono($_POST['telefono1']);
                $this->objProveedor->setTelefonoSecundario($_POST['telefono2']);
                $this->objProveedor->setSitioWeb($_POST['sitio_web']);
                $this->objProveedor->setCiudad($_POST['ciudad']);
                $this->objProveedor->setDireccion($_POST['direccion']);

                if(isset($_POST['estado'])){
                    $this->objProveedor->setEstado(1);
                }else{
                    $this->objProveedor->setEstado(0);
                }


                $respuesta = $this->model->store($this->objProveedor);
                $this->validaciones->store($respuesta);

                $arrResponse = array('status' => true, 'msg' => 'Proveedor Creado Correctamente', 'title' => 'Correcto','icon'=>'success');
            } catch (Exception $e) {
                $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' =>'error');
            }
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
        }
        die();
    }

    public function edit($id)
    {
        // TODO: Implement edit() method.
    }

    public function update()
    {
        // TODO: Implement update() method.
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
        try {
            $respuesta = $this->model->deleteProveedor($id);

            $arrResponse = array('status' => true, 'msg' => 'Proveedor Eliminado de Forma Correcta',
                'title' => 'Correcto', 'icon' => 'success', 'data' => $respuesta);

        } catch (Exception $e) {
            $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' => 'error');
        }
        echo json_encode($arrResponse, JSON_UNESCAPED_UNICODE);
    }
}