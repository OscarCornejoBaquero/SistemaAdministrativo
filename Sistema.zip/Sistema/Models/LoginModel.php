<?php

class LoginModel extends Mysql
{
    private User $objUsuario;
    public function __construct()
    {
        parent::__construct();
    }
    public function login(User $objUser){
        $this->objUsuario = $objUser;
        $sql = "call loginUserValidar('{$this->objUsuario->getUsername()}')";
        $request = $this->select($sql);
        if(!empty($request)){
            $sql = "call login('{$this->objUsuario->getUsername()}', '{$this->objUsuario->getPassword()}')";
            $request = $this->select($sql);

            if(!$request){
                $return = "loginInvalido";
            }else{
                $return = $request;
            }
        }else{
            $return = "loginInvalido";
        }
        return  $return;
    }
    public function getIdEmpresa($id){
        $sql = "call getPrimeraEmpresa('{$id}')";
        return $this->select($sql);
    }
    public function getAllEmpresas($id){
        $sql = "call getAllEmpresas('{$id}')";
        return $this->select_all($sql);
    }
}