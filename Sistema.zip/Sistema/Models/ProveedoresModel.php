<?php
require_once("Objetos/Empresa/Proveedor.php");
class ProveedoresModel extends Mysql
{
    private Proveedor $objProveedor;
    public function __construct()
    {
        parent::__construct();

    }
    public function getDataTable(){
        $sql = "call getAllProveedoresDataTable('{$_SESSION['id_user']}')";
        return $this->select_all($sql);
    }
    public function store(Proveedor $objProveedor){
        $this->objProveedor = $objProveedor;
        $sql = "call validarProveedorExiste('{$this->objProveedor->getRuc()}') ";
        $request = $this->select($sql);

        if(empty($request)){
            $sql = "call storeProveedor(?,?,?,?,?,?,?,?,?,?)";
            $arrData = array( $this->objProveedor->getRazonSocial(), $this->objProveedor->getRuc(),
                $this->objProveedor->getEmail(),$this->objProveedor->getTelefono(),
                $this->objProveedor->getTelefonoSecundario(), $this->objProveedor->getDireccion(),
                $this->objProveedor->getCiudad(),$this->objProveedor->getEstado(), $this->objProveedor->getSitioWeb(), $_SESSION['id_user']);
            $request_store = $this->insert($sql,$arrData);
            $return = $request_store;
        }else{
            $return = "Proveedor Existe";

        }
        return  $return;
    }
    public function show($id){
        $sql = "call infoProveedor('{$id}') ";
        return $this->select($sql);
    }
    public function deleteProveedor($id){
        $sql = "call eliminarProveedor('{$id}')";
        return $this->delete($sql);
    }
}