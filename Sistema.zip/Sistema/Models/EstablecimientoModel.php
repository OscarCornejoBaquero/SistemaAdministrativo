<?php
require_once ("Objetos/Empresa/Sucursal.php");
class EstablecimientoModel extends Mysql
{
    private Sucursal $objSucursal;
    public function __construct()
    {
        parent::__construct();

    }
    public function selectAllEstablecimientos($id_user){
        $sql = "call SucursalesPorUsuario('{$id_user}') ";
        return $this->select_all($sql);
    }
    public function selectEstablecimientoEmpresa($id_user, $id_empresa){
        $sql = "call SucursalesEmpresaUsuario('{$id_user}','{$id_empresa}') ";
        return $this->select_all($sql);
    }
    public function selectAllPuntoEmision($idSucursal){
            $sql = "select * from tb_punto_emision where id_sucursal = '".$idSucursal."'";
            return $this->select_all($sql);
    }
    public function selectInformacionEstablecimiento($id_establecimiento){
        $sql = "call informacionSucursal('{$id_establecimiento}') ";
        return $this->select($sql);
    }
    public function selectInformacionEmpresa($id_empresa){
        $sql = "call inforEmpresa('{$id_empresa}') ";
        return $this->select($sql);
    }
    public function selectCodigoEstablecimiento($idEmpresa){
        $sql = "call ultimaSucursalPorEmpresa('{$idEmpresa}')";
        return $this->select($sql);
    }
    public function existeMatriz($idEmpresa){
        $sql = "call existeMatriz('{$idEmpresa}')";
        return $this->select($sql);
    }
    public function storeEstablecimientos(Sucursal $objSucursal){
        $this->objSucursal = $objSucursal;
        $sql = "call validarSucursalExiste('{$this->objSucursal->getCodigoSucursal()}','{$this->objSucursal->getIdEmpresa()}') ";
        $request = $this->select($sql);

        if(empty($request)){
            $sql = "call storeSucursal(?,?,?,?,?,?,?,?)";
            $arrData = array( $this->objSucursal->getIdEmpresa(), $this->objSucursal->getIsMatriz(),
                $this->objSucursal->getCodigoSucursal(),$this->objSucursal->getNombreSucursal(),
                $this->objSucursal->getDireccionSucursal(), $this->objSucursal->getNombreComercial(),
                $this->objSucursal->getLogoSucursal(),$this->objSucursal->getEstado());
            $request_store = $this->insert($sql,$arrData);
            $return = $request_store;
        }else{
            $return = "Establecimiento Existe";

        }
        return  $return;
    }
    public function updateEstablecimiento(Sucursal $objSucursal){
        $this->objSucursal = $objSucursal;
        $sql = "call validarSucursalExiste('{$this->objSucursal->getCodigoSucursal()}','{$this->objSucursal->getIdEmpresa()}') ";
        $request = $this->select($sql);
        if($this->objSucursal->getLogoSucursal() == null || $this->objSucursal->getLogoSucursal() == ""){
            $this->objSucursal->setLogoSucursal($request['logo_empresa']);
        }

        if(empty($request)){
            $return = "No Existe";
        }else{
            if($request['is_matriz'] == 0){
                $sql = "call validarExisteMatriz('{$this->objSucursal->getIdEstablecimiento()}')";
                $request = $this->select($sql);
                if(empty($request)){
                    $sql = "call updateEstablecimientow(?,?,?,?,?,?,?,?)";
                    $arrData = array($this->objSucursal->getIdEstablecimiento(), $this->objSucursal->getIsMatriz(),
                        $this->objSucursal->getCodigoSucursal(),$this->objSucursal->getNombreSucursal(),
                        $this->objSucursal->getDireccionSucursal(), $this->objSucursal->getNombreComercial(),
                        $this->objSucursal->getLogoSucursal(),$this->objSucursal->getEstado()
                    );
                    $request_update = $this->update($sql,$arrData);
                    $return = $request_update;
                }else{
                    $return = "Error en Matriz";
                }
            }else{
                $sql = "call updateEstablecimientow(?,?,?,?,?,?,?,?)";
                $arrData = array($this->objSucursal->getIdEstablecimiento(), $this->objSucursal->getIsMatriz(),
                    $this->objSucursal->getCodigoSucursal(),$this->objSucursal->getNombreSucursal(),
                    $this->objSucursal->getDireccionSucursal(), $this->objSucursal->getNombreComercial(),
                    $this->objSucursal->getLogoSucursal(),$this->objSucursal->getEstado()
                );
                $request_update = $this->update($sql,$arrData);
                $return = $request_update;
            }

        }
        return  $return;
    }
    public function eliminarEstablecimiento($id){
        $sql = "call informacionSucursal('{$id}') ";
        $consulta = $this->select($sql);
        $nombre_fichero = $_SERVER['DOCUMENT_ROOT']."/facturero/Assets/img/empresas/sucursales/logos/" .$consulta['logo_sucursal'];
        if($consulta['logo_sucursal'] == "default.jpg"){
            $sql = "call eliminarEstablecimiento('{$id}')";
            return $this->delete($sql);
        }else{
            if (file_exists($nombre_fichero)) {
                unlink($nombre_fichero);
            }
            $sql = "call eliminarEstablecimiento('{$id}')";
            return $this->delete($sql);
        }



    }

}