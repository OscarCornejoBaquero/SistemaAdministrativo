$(document).ready(function() {
    $('.js-example-basic-single').select2(
        {
            width: '100%',
            placeholder: "Seleccionar"
        }
    );

});

//Funcion para cargar la tabla
var tableProveedores;
function requestAll(){
    return  request = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
}
document.addEventListener('DOMContentLoaded', function(){
    tableProveedores = $('#tableProveedores').DataTable( {
        "aProcessing":true,
        "aServerSide":true,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
        },
        "ajax":{
            "url": " "+base_url+"proveedores/getDataTable",
            "dataSrc":""
        },
        "columns":[
            {"data":"id_proveedor"},
            {"data":"razon_social"},
            {"data":"ruc_proveedor"},
            {"data":"telefono1"},
            {"data":"correo_proveedor"},
            {"data":"estado"},
            {"data":"options"}
        ],
        'dom': 'Bfrtip',

        'buttons': [
            {
                "extend": "copyHtml5",
                "text": "<i class='far fa-copy'></i> Copiar",
                "titleAttr":"Copiar",
                "className": "btn btn-secondary"
            },{
                "extend": "excelHtml5",
                "text": "<i class='fas fa-file-excel'></i> Excel",
                "titleAttr":"Exportar a Excel",
                "className": "btn btn-success"
            },{
                "extend": "pdfHtml5",
                "text": "<i class='fas fa-file-pdf'></i> PDF",
                "titleAttr":"Exportar a PDF",
                "messageTop": "Reporte General de Proveedores",
                "className": "btn btn-danger",
                "exportOptions": {
                    "columns": [ 1,2,3,4,5]
                }
            }
        ],
        "resonsieve":"true",
        "bDestroy": true,
        "autoFill": true,
        "iDisplayLength": 10,
        "order":[[0,"acs"]]
    });

}, false);

//Funcion que se puede replicar en todos los archivos
$(document).ready(function(){
    $("#provincia").change(function(){
        var id_provincia= $(this).children("option:selected").val();
        $.ajax({
            type: "GET",
            url: ""+base_url+"proveedores/getCiudades/"+id_provincia,
            beforeSend: function(){
            },
            success: function(data){
                var objData = JSON.parse(data);
                console.log(objData);
                $('#ciudad').empty();
                objData.forEach(function(ciudad, index) {
                    $("#ciudad").append("<option value='"+ciudad.id_ciudad+"'>"+ciudad.nombre_ciudad+"</option>");
                });
            },
            error: function(data){
                Swal.fire({
                    title: 'Error',
                    text: 'Problemas al cargar los datos de las Ciudades',
                    icon: 'error',
                    showCancelButton: false,
                    confirmButtonColor: '#3085d6',
                }).then((result) => {
                    location.reload();
                })
            }
        });
    });
});
//Funcion de creación de Proveedor
$(document).ready(function () {
    $("#formCrearProveedor").bind("submit", function (e) {
        // Capturamnos el boton de envío
        if(validar() == true){
            var btnEnviar = $("#btn-enviar");
            var formData = new FormData(this);
            e.preventDefault();
            console.log(formData);
            $.ajax({
                type: $(this).attr("method"),
                url: $(this).attr("action"),
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function () {
                },
                complete: function (data) {
                },
                success: function (data) {

                    var objData = JSON.parse(data);
                    var respuesta = objData.msg;
                    var title = objData.title;
                    var icon = objData.icon;
                    console.log(objData);
                    Swal.fire({
                        title: title,
                        text: respuesta,
                        icon: icon,
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        if (title != "Error") {
                            window.location.href = '../../facturero/proveedores'
                        } else {
                            location.reload();
                        }
                    })
                },
                error: function (data) {
                    Swal.fire({
                        title: 'Error',
                        text: 'Problemas al tratar de enviar el formulario',
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        location.reload();
                    })
                }
            });
            return false;
        }else{
            Swal.fire({
                title: 'Error',
                text: 'Debe de Rellenar los campos requeridos.',
                icon: 'error',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
            }).then((result) => {

            })
            e.preventDefault();
        }
    });
});

function openModal(data)
{
    var ajaxUrl = base_url+'proveedores/show/'+data;
    $.ajax({
        type: 'get',
        url: ajaxUrl,
        data: data,
        cache:false,
        contentType: false,
        processData: false,
        beforeSend: function(){
        },
        complete:function(data){
        },
        success: function(data){
            var objData = JSON.parse(data);
            var data = objData.data;
            console.log(data);

            $('#id_proveedor').val(data['id_proveedor']);
            $('#razon_social').text(data['razon_social']);
            $('#ruc_social').text(data['ruc_proveedor']);
            $('#correo_proveedor').text(data['correo_proveedor']);
            $('#telefono1').text(data['telefono1']);
            $('#telefono2').text(data['telefono2']);
            $('#direccion').text(data['direccion']);
            $('#nombre_ciudad').text(data['nombre_ciudad']);
            $('#nombre_provincia').text(data['nombre_provincia']);


            $('#modalProveedor').modal('show');
        },
        error: function(data){
            Swal.fire({
                title: 'Error',
                text: 'Problemas al procesar la consulta',
                icon: 'error',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
            }).then((result) => {
                location.reload();
            })
        }
    });

}
function editarProveedor(){
    idProveedor = $('#id_proveedor').val();
    window.location.href = '../../facturero/proveedores/edit/'+idProveedor;
}
/*
$(function() {
    $("form[name='proveedor']").validate({
        rules: {
            fullname: "required",
            ruc: {
              required:true,
                minlength: 13
            },
            email: {
                required: true,
                email: true
            },
            telefono1: {
                required: true,
                minlength: 10
            },
            provincia:{
                required: true
            },
            ciudad:{
                required:true
            },
            direccion: {
                required:true,
                minlength: 20
            }
        },

        messages: {
            fullname: "Por favor, agregue la Razón Social",
            ruc: {
                required: "Por favor, debe de agregar un RUC",
                minlength: "Su RUC debe de tener al menos 13 caracteres."
            },
            direccion: {
                required: "Por favor proporcione una dirección",
                minlength: "Su dirección debe de tener al menos 20 caracteres."
            },
            email: "Por favor, introduce una dirección de correo electrónico válida",
            telefono1: {
                required: "Debe de Ingresar un Número de teléfono principal. "
            },
            provincia:"Seleccione una provincia",
            ciudad:"Seleccione una ciudad"
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
});
*/
function validar() {
       let razon_social = $('#fullname').val();
       let ruc = $('#ruc').val();
       let correo = $('#email').val();
       let telefono = $('#telefono1').val();
       let direccion = $('#direccion').val();
       var id_provincia = $('#provincia').children("option:selected").val();
       if(razon_social != ""){

            if( ruc != "" ){
                if( correo != "" ){
                    if(telefono != ""){
                        if(direccion != ""){
                            if(id_provincia != "Seleccione"){
                                return true;
                            }else{
                                return false;
                            }
                        }else{
                            return false;
                        }
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }else {
            return false;
        }
}

function eliminar(id){

    Swal.fire({
        title: 'Esta Seguro que desea Eliminar el Proveedor?',
        text: "Recuerde que esta Operación es Irreversible. ",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si Eliminar Proveedor'
    }).then((result) => {
        if (result.isConfirmed) {
            var ajaxUrl = base_url+'proveedores/delete/'+id;

            $.ajax({
                type: 'get',
                url: ajaxUrl,
                data: id,
                cache: false,
                contentType: false,
                processData: false,
                success: function (data) {
                    /*
                    * Se ejecuta cuando termina la petición y esta ha sido
                    * correcta
                    * */
                    var objData = JSON.parse(data);
                    var respuesta = objData.msg;
                    var title = objData.title;
                    var icon = objData.icon;
                    console.log(objData);
                    Swal.fire({
                        title: title,
                        text: respuesta,
                        icon: icon,
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        if (title != "Error") {
                            window.location.href = '../../facturero/proveedores';
                        } else {
                            location.reload();
                        }

                    })
                },
                error: function (data) {
                    /*
                    * Se ejecuta si la peticón ha sido erronea
                    * */
                    Swal.fire({
                        title: 'Error',
                        text: 'Problemas al tratar de eliminar el proveedor.',
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        location.reload();
                    })
                }
            });

        }
    })
}