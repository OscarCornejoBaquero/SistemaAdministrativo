<?php

class ProductosModel extends Mysql
{

    public function getDataTable(){
        $sql = "call getAllProductosDataTable('{$_SESSION['id_empresa']['id_empresa']}')";
        return $this->select_all($sql);
    }
    public function getCategoriasEmpresas(){
        $sql = "call getAllCategoriasDataTable('{$_SESSION['id_empresa']['id_empresa']}')";
        return $this->select_all($sql);
    }
}