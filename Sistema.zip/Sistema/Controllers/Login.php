<?php
require_once ("Objetos/Login/User.php");
require_once ("Excepciones/ExLogin.php");
class Login extends Controllers{
    private User $objUsuario;
    private ExLogin $validaciones;
    public function __construct()
    {
        session_start();
        parent::__construct();
        $this->validaciones = new ExLogin();
    }
    public function login(){
        $data['tag_page'] = "Login";
        $data['page_title'] = "Login de Prueba";
        $data['page_name'] = "login";
        $this->views->getView($this,"login",$data);
    }

    public function loginUser(){
        if($_POST){
            try {
                $this->objUsuario = new User();
                $this->objUsuario->setUsername($_POST['email-username']);
                $this->objUsuario->setPassword(md5($_POST['password']));
                $respuesta = $this->model->login($this->objUsuario);

                $this->validaciones->errorLogin($respuesta);
                $_SESSION['id_user'] = $respuesta['id_usuario'];
                $_SESSION['login'] = true;
                $_SESSION['user_data']= $respuesta;
                $idEmpresa = $this->model->getIdEmpresa($_SESSION['id_user']);
                $_SESSION['id_empresa'] = $idEmpresa;
                $empresas = $this->model->getAllEmpresas($_SESSION['id_user']);
                $_SESSION['empresas'] = $empresas;
                $arrResponse = array('status' => true, 'msg' => 'Usuario Encontrado Bienvenido',
                                    'title' => 'Correcto','icon'=>'success', 'data' => $respuesta);

            }catch (Exception $e){
                $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' =>'error');
            }
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
        }
        die();
    }

    public function logout(){

    }
}