<?php
require_once("Models/NavModel.php");
class Home extends Controllers{
    public function __construct()
    {
        session_start();
        parent::__construct();
    }
    public function home(){
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();
        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['tag_page'] = "Home";
        $data['page_title'] = "Página prueba pepa";
        $data['page_name'] = "home";

       $this->views->getView($this,"Login/login",$data);
    }

}
?>