<?php

class CategoriasModel extends Mysql
{
    public function __construct()
    {
        parent::__construct();

    }
    public function getDataTable(){
        $sql = "call getAllCategoriasDataTable('{$_SESSION['id_empresa']['id_empresa']}')";
        return $this->select_all($sql);
    }
    public function getCategoriaCreate(){
        $sql = "call getCategoriaCreate()";
        return $this->select($sql);
    }
    public function store($nombre, $descripcion){

        $sql = "call validarCategoriaExiste('{$nombre}') ";
        $request = $this->select($sql);

        if(empty($request)){
            $sql = "call storeCategoria(?,?,?)";
            $arrData = array( $nombre, $descripcion, $_SESSION['id_empresa']['id_empresa']);
            $request_store = $this->insert($sql,$arrData);
            $return = $request_store;
        }else{
            $return = "Categoria Existe";

        }
        return  $return;
    }
    public function show($id){
        $sql = "call infoCategoria('{$id}') ";
        return $this->select($sql);
    }
    public function updateCategoria($nombre, $descripcion, $id){

        $sql = "call validarCategoriaExisteID('{$id}') ";
        $request = $this->select($sql);

        if(empty($request)){
            $return = "Categoria No Existe";
        }else{

            $sql = "call updateCategoria(?,?,?)";
            $arrData = array( $nombre, $descripcion, $id);
            $request_store = $this->update($sql,$arrData);
            $return = $request_store;
        }
        return  $return;
    }
    public function deleteCategoria($id){
        $sql = "call eliminarCategoria('{$id}')";
        return $this->delete($sql);
    }
}