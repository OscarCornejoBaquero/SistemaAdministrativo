<?php
require_once("Models/NavModel.php");
require_once ("Excepciones/ExProductos.php");
require_once("Models/Crud.php");
class Productos extends Controllers implements Crud
{

    private ExProductos $validaciones ;
    public function __construct()
    {
        session_start();
        if (empty($_SESSION['login'])) {
            header('Location: ' . base_url());
        }
        parent::__construct();
        $this->validaciones = new ExProductos();
    }
    public function productos(){
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();
        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        //$data['categorias'] =  $this->model->getCategoriaCreate();
        $data['tag_page'] = "Productos";
        $data['page_title'] = "Producto";
        $data['page_name'] = "Productos de la Empresa";
        $this->views->getView($this, "productos", $data);
    }
    public function getDataTable()
    {
        // TODO: Implement getDataTable() method.
        $arrData = $this->model->getDataTable();
        for ($i = 0; $i < sizeof($arrData); $i++) {
            $datos = $arrData[$i]['id_producto'];
            if ($arrData[$i]['estado'] == 1) {
                $arrData[$i]['estado'] = '<span class="badge badge-success" style="background: green">Activo</span>';
            } else {
                $arrData[$i]['estado'] = '<span class="badge badge-danger" style="background: red">Inactivo</span>';
            }
            $arrData[$i]['options'] = '
            <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu">
                                
                                <a class="dropdown-item" href="'.base_url().'productos/edit/'.$datos.'"
                                ><i class="bx bx-edit-alt me-1"></i> Editar</a
                                >
                                <a class="dropdown-item " href="#" onclick="eliminar('.$datos.');"
                                ><i class="bx bx-trash me-1"></i> Eliminar</a
                                >
                            </div>
                        </div>
            ';
        }
        echo json_encode($arrData, JSON_UNESCAPED_UNICODE);
        die();
    }

    public function show($id)
    {
        // TODO: Implement show() method.
    }

    public function create()
    {
        // TODO: Implement create() method.
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();
        $arrCategorias = $this->model->getCategoriasEmpresas();
        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['categoriasEmpresa'] = $arrCategorias;
        $data['tag_page'] = "Crear Producto";
        $data['page_title'] = "Crear Producto";
        $data['page_name'] = "Creación de Productos para las Empresas";
        $this->views->getView($this, "create", $data);
    }

    public function store()
    {
        // TODO: Implement store() method.
    }

    public function edit($id)
    {
        // TODO: Implement edit() method.
    }

    public function update()
    {
        // TODO: Implement update() method.
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
    }
}