<?php

class NavModel extends Mysql
{
    public function __construct()
    {
        parent::__construct();
    }
    public function getMenusHijos(){
        $sql = "select id_modulo, id_moduloPadre, nombre, menu_hijo,icono,link, estado from tb_modulo where id_moduloPadre != 0 and estado != 1 ";
        return  $this->select_all($sql);
    }
    public function getMenusPadres(){
        $sql = "select id_modulo, id_moduloPadre, nombre, menu_hijo,icono,link from tb_modulo where id_moduloPadre = 0";
        return  $this->select_all($sql);
    }
}