<?php
headers($data);
?>


    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"> Datos Tributarios / Establecimiento / Sucursal / </span> <?php echo $data['tag_page']?></h4>

        <!-- Basic Bootstrap Table -->
        <div class="card">
            <div class="row">
                <div class="col-9">
                    <h5 class="card-header"><?php echo $data['tag_page'] ?></h5>
                </div>
                <div class="col-sm-12 col-lg-3  card-header">
                    <a type="button" class="btn btn-outline-warning " href="<?php echo base_url()?>establecimiento/crearPuntoEmision" style="color: black" title="Agregar Establecimiento / Sucursal">
                        <span class="tf-icons bx bx-plus" ></span>&nbsp; Punto de Emisión
                    </a>
                </div>
            </div>
            <input type="hidden" name="idPunto" id="idPunto" value="<?php echo $data['idSucursal'] ?>">
            <div class="card-body">
                <div class="table-responsive ">
                    <table class="table table-striped" id="tablePuntoEmision">
                        <thead>
                        <tr>
                            <th>NOMBRE PUNTO DE EMISIÓN</th>
                            <th>DETALLE DEL PUNTO DE EMISIÓN</th>
                            <th>ESTADO</th>
                            <th>OPCIONES</th>
                        </tr>
                        </thead>
                        <tbody >

                        </tbody>
                    </table>
                </div>
            </div>
        </div>


    </div>

<?php
scripts($data);
?>
    <script src="<?php echo media()?>/js/web/puntoEmision.js"></script>
<?php
fin();
?>