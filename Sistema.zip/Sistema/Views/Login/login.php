<!DOCTYPE html>
<html
    lang="en"
    class="light-style customizer-hide"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="../assets/"
    data-template="vertical-menu-template-free"
>
<head>
    <meta charset="utf-8" />
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title><?php echo $data['tag_page'] ?></title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon"  href="<?php echo media()?>/img/iconoMacrogram.png" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
        rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="<?php echo media()?>vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="<?php echo media()?>vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="<?php echo media()?>vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="<?php echo media()?>css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?php echo media()?>vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->
    <!-- Page -->
    <link rel="stylesheet" href="<?php echo media()?>vendor/css/pages/page-auth.css" />
    <!-- Helpers -->
    <script src="<?php echo media()?>vendor/js/helpers.js"></script>
    <script src="<?php echo media()?>js/config.js"></script>
</head>

<body>
<!-- Content -->

<div class="container-xxl">
    <div class="authentication-wrapper2 authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner">
            <!-- Register -->
            <div class="card">
                <div class="card-body">
                    <!-- Logo -->
                    <div class="app-brand justify-content-center">
                        <img class="app-brand-link gap-2" width="100%" src="<?php echo media()?>img/login/logo.png">
                    </div>
                    <!-- /Logo -->
                    <h4 class="mb-2">Bienvenido a Macrogram! 👋</h4>
                    <p class="mb-4">El mejor y más completo sistema de Facturación Online del Ecuador</p>

                    <form id="formAuthentication" class="mb-3" action="<?php echo base_url()?>login/loginUser" method="POST">
                        <div class="mb-3">
                            <label for="email" class="form-label">Correo o Usuario</label>
                            <input
                                type="text"
                                class="form-control"
                                id="email"
                                name="email-username"
                                placeholder="Ingresa tu Correo o Usuario"
                                autofocus
                            />
                        </div>
                        <div class="mb-3 form-password-toggle">
                            <div class="d-flex justify-content-between">
                                <label class="form-label" for="password">Contraseña</label>
                                <a href="auth-forgot-password-basic.html">
                                    <small>Olvidaste tu contraseña?</small>
                                </a>
                            </div>
                            <div class="input-group input-group-merge">
                                <input
                                    type="password"
                                    id="password"
                                    class="form-control"
                                    name="password"
                                    placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                    aria-describedby="password"
                                />
                                <span class="input-group-text cursor-pointer" "><i class="bx bx-hide"></i></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="remember-me" />
                                <label class="form-check-label" for="remember-me"> Recuerdame </label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <button class="btn btn-primary d-grid w-100" id="btn-enviar"  type="submit">Iniciar</button>
                        </div>
                    </form>

                    <p class="text-center">
                        <span>Eres nuevo en nuesta plataforma?</span>
                        <a href="<?=base_url()?>registro">
                            <span>Create una cuenta con nosotros...</span>
                        </a>
                    </p>
                </div>
            </div>
            <!-- /Register -->
        </div>
    </div>
</div>

<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="<?php echo media()?>vendor/libs/jquery/jquery.js"></script>
<script src="<?php echo media()?>vendor/libs/popper/popper.js"></script>
<script src="<?php echo media()?>vendor/js/bootstrap.js"></script>
<script src="<?php echo media()?>vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo media()?>vendor/js/menu.js"></script>
<!-- endbuild -->

<!-- Vendors JS -->

<!-- Main JS -->
<script src="<?php echo media()?>js/main.js"></script>

<!-- Page JS -->
<script src="<?php echo media()?>js/web/login.js"></script>
<!-- Place this tag in your head or just before your close body tag. -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
</body>
</html>
