<div class="modal fade" id="modalEstablecimiento" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">


                <h5 class="modal-title centrado" id="titleEstablecimiento"></h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="id_establecimiento">
                <div class="row">
                    <div class="col-12">
                        <table class="table table-bordered"  >
                            <tbody >
                            <tr>
                                <td class="formatoTableModal">Empresa:</td>
                                <td id="nombre_comerial_empresa" class="formatoTableModal"></td>
                            </tr>
                            <tr>
                                <td class="formatoTableModal">Código de la Sucursal:</td>
                                <td id="codigo_sucursal" class="formatoTableModal"></td>
                            </tr>
                            <tr>
                                <td class="formatoTableModal">Nombre Sucursal:</td>
                                <td id="nombre_sucursal" class="formatoTableModal"></td>
                            </tr>
                            <tr>
                                <td class="formatoTableModal">Dirección Sucursal:</td>
                                <td id="direccion_sucursal"class="formatoTableModal"></td>
                            </tr>
                            <tr>
                                <td sclass="formatoTableModal">Nombre Comercial:</td>
                                <td id="nombre_comercial_sucursal"class="formatoTableModal"></td>
                            </tr>

                            <tr>
                                <td class="formatoTableModal">Logo: </td>
                                <td id="logo"class="formatoTableModal"><img
                                        src=""
                                        alt="logo_sucursal"
                                        class="d-grid centrado"
                                        width="100"
                                        id="logo_sucursal"
                                    /></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cerrar
                </button>
                <button type="button" class="btn btn-primary" onclick="editarEstablecimiento();" >Editar Establecimiento</button>
            </div>
        </div>
    </div>
</div>