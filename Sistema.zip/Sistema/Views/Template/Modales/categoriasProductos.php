<div class="modal fade" id="modalCategoriasProductos" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">


                <h5 class="modal-title centrado" id="titleCategoria"></h5>

                <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"
                ></button>
            </div>

            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <form id="formCrearCategoria" name="categoria" method="POST" action="<?php echo base_url()?>categorias/store" enctype="multipart/formdata" >
                            <div class="row mb-3">
                                <input type="hidden" name="idCategoria" id="idCategoria">
                                <label class="col-sm-2 col-form-label" for="basic-icon-default-fullname">Nombre de la Categoria <span class="requerido">*</span></label>
                                <div class="col-sm-10">
                                    <div class="input-group input-group-merge">
                                        <span id="fullname2" class="input-group-text"><i class="bx bx-user"></i></span>
                                        <input type="text" class="form-control" id="nombreCategoria" name="nombreCategoria"

                                               placeholder="Nombre de la Categoria" aria-label="nombreCategoria" aria-describedby="nombreCategoria">
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-icon-default-company">Descripción de la Categoria <span class="requerido">*</span></label>
                                <div class="col-sm-10">
                                    <div class="input-group input-group-merge">
                                        <span id="ruc2" class="input-group-text"><i class="bx bx-buildings"></i></span>
                                        <input type="text" id="descripcion" name="descripcion" class="form-control"

                                               placeholder="Descripcion " aria-label="ruc" aria-describedby="ruc">
                                    </div>
                                </div>
                            </div>

                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cerrar
                </button>
                <button type="submit" id="btn-enviar" class="btn btn-primary">Guardar Categoria</button>
            </div>
            </form>
        </div>
    </div>
</div>