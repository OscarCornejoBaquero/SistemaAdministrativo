<?php
    class homeModel extends Mysql{
        public function __construct()
        {
           parent::__construct();
        }

        public function getMenu(){
            $sql = "select * from tb_modulo_padre";
            return  $this->select_all($sql);
        }

    }
?>