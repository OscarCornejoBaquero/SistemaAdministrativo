<?php
require_once("Models/NavModel.php");
require_once ("Excepciones/ExEstablecimiento.php");
require_once ("Objetos/Empresa/Sucursal.php");
class Establecimiento extends Controllers
{
    private Sucursal $objSucursal;
    private ExEstablecimiento $validaciones ;
    public function __construct()
    {
        session_start();
        if (empty($_SESSION['login'])) {
            header('Location: ' . base_url());
        }
        parent::__construct();
        $this->validaciones = new ExEstablecimiento();
    }
    public function establecimiento()
    {
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();

        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['tag_page'] = "Información Establecimientos";
        $data['page_title'] = "Información Establecimiento";
        $data['page_name'] = "Información Establecimientos";
        $this->views->getView($this, "establecimientos", $data);
    }
    public function establecimientosEmpresas($id)
    {
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();

        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['idEmpresa'] = $id;
        $data['tag_page'] = "Información Establecimientos";
        $data['page_title'] = "Información Establecimiento";
        $data['page_name'] = "Información Establecimientos";
        $this->views->getView($this, "establecimientosEmpresa", $data);
    }
    public function crearEstablecimiento($idEmpresa){
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();

        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['empresa'] = $this->model->selectInformacionEmpresa($idEmpresa);
        $data['ultimaSucursal'] = $this->model->selectCodigoEstablecimiento($idEmpresa);
        $data['isMatriz'] = $this->model->existeMatriz($idEmpresa);
        $data['tag_page'] = "Agregar Establecimiento";
        $data['page_title'] = "Agregar información Establecimiento";
        $data['page_name'] = "Agregar Establecimiento";
        $this->views->getView($this, "crearEstablecimiento", $data);
    }
    public function storeEstablecimiento(){
        if($_POST){
            try {
                $this->objSucursal = new Sucursal();
                $this->objSucursal->setIdEmpresa($_POST['id_empresa']);
                $this->objSucursal->setCodigoSucursal($_POST['codigo_sucursal']);
                $this->objSucursal->setNombreSucursal($_POST['nombre_sucursal']);
                $this->objSucursal->setNombreComercial($_POST['nombre_comercial_sucursal']);
                $this->objSucursal->setDireccionSucursal($_POST['direccion_sucursal']);
                $this->objSucursal->setEstado(1);
                if(isset($_POST['is_matriz'])){
                    $this->objSucursal->setIsMatriz(1);
                }else{
                    $this->objSucursal->setIsMatriz(0);
                }


                $newName="";
                $archivo = $_FILES['upload']['name'];
                if (isset($archivo) && $archivo != "") {
                    $array = explode('.', $_FILES['upload']['name']);
                    $tipo = end($array);
                    $newName = "logo_Sucursal" .$this->objSucursal->getDireccionSucursal(). $this->objSucursal->getCodigoSucursal() .'.'. $tipo;
                    if(move_uploaded_file($_FILES["upload"]["tmp_name"], $_SERVER['DOCUMENT_ROOT']."/facturero/Assets/img/empresas/sucursales/logos/" . $newName)){
                        // $this->objEmpresa->setUrlFoto($newName);
                    }
                    $this->objSucursal->setLogoSucursal("$newName");
                }else{
                    $this->objSucursal->setLogoSucursal("default.jpg");
                }


                $respuesta = $this->model->storeEstablecimientos($this->objSucursal);
                $this->validaciones->store($respuesta);

                $arrResponse = array('status' => true, 'msg' => 'Establecimiento Creado Correctamente', 'title' => 'Correcto','icon'=>'success');
            } catch (Exception $e) {
                $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' =>'error');
            }
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
        }
        die();
    }

    public function getAll()
{
    $arrData = $this->model->selectAllEstablecimientos($_SESSION['id_user']);


    for ($i = 0; $i < sizeof($arrData); $i++) {

        $datos = $arrData[$i]['id_sucursal'];
        $arrData[$i]['id_sucursal'] = '<button class="btn p-0 dropdown-toggle hide-arrow" onclick="openModal(' . $datos . ');" title="Ver Información del Establecimiento"><i class="menu-icon tf-icons bx bx-show"></i></button>';
        if ($arrData[$i]['estadoSucursal'] == 1) {
            $arrData[$i]['estadoSucursal'] = '<span class="badge badge-success" style="background: green">Activo</span>';
        } else {
            $arrData[$i]['estadoSucursal'] = '<span class="badge badge-danger" style="background: red">Inactivo</span>';
        }

        $arrData[$i]['acciones'] = '
            <a class="dropdown-item " href="'.base_url().'/establecimiento/nuevoPuntoEmision/'.$datos.'" 
                                ><i class="bx bx-add-to-queue me-1"></i> Puntos de Emisión</a
                                >
            ';

        $arrData[$i]['options'] = '
            <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu">
                                
                                <a class="dropdown-item" href="'.base_url().'informacion/editarEmpresa/'.$datos.'"
                                ><i class="bx bx-edit-alt me-1"></i> Editar</a
                                >
                                <a class="dropdown-item " href="#" onclick="eliminar('.$datos.');"
                                ><i class="bx bx-trash me-1"></i> Eliminar</a
                                >
                            </div>
                        </div>
            ';
    }

    echo json_encode($arrData, JSON_UNESCAPED_UNICODE);
    die();
}
    public function getSucursalesEmpresas($id_empresa)
    {
        $arrData = $this->model->selectEstablecimientoEmpresa($_SESSION['id_user'], $id_empresa);


        for ($i = 0; $i < sizeof($arrData); $i++) {

            $datos = $arrData[$i]['id_sucursal'];
            $arrData[$i]['id_sucursal'] = '<button class="btn p-0 dropdown-toggle hide-arrow" onclick="openModal(' . $datos . ');" title="Ver Información del Establecimiento"><i class="menu-icon tf-icons bx bx-show"></i></button>';
            if ($arrData[$i]['estadoSucursal'] == 1) {
                $arrData[$i]['estadoSucursal'] = '<span class="badge badge-success" style="background: green">Activo</span>';
            } else {
                $arrData[$i]['estadoSucursal'] = '<span class="badge badge-danger" style="background: red">Inactivo</span>';
            }
            $arrData[$i]['codigo_sucursal'] = "00".$arrData[$i]['codigo_sucursal'];
            $arrData[$i]['acciones'] = '
            <a class="dropdown-item " href="'.base_url().'/establecimiento/nuevoPuntoEmision/'.$datos.'" 
                                ><i class="bx bx-add-to-queue me-1"></i> Puntos de Emisión</a
                                >
            ';

            $arrData[$i]['options'] = '
            <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu">
                                
                                <a class="dropdown-item" href="'.base_url().'establecimiento/editarEstablecimiento/'.$datos.'"
                                ><i class="bx bx-edit-alt me-1"></i> Editar</a
                                >
                                <a class="dropdown-item " href="#" onclick="eliminar('.$datos.');"
                                ><i class="bx bx-trash me-1"></i> Eliminar</a
                                >
                            </div>
                        </div>
            ';
        }

        echo json_encode($arrData, JSON_UNESCAPED_UNICODE);
        die();
    }
    public function nuevoPuntoEmision($id){

        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();

        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['idSucursal'] = $id;
        $data['tag_page'] = "Punto de Emisión";
        $data['page_title'] = "Información Punto de Emisión";
        $data['page_name'] = "Punto de Emisión";
        $this->views->getView($this, "nuevoPuntoEmision", $data);
    }
    public function getAllPuntoEmision($idSucursal)
    {

        $arrData = $this->model->selectAllPuntoEmision($idSucursal);


        for ($i = 0; $i < sizeof($arrData); $i++) {

            $datos = $arrData[$i]['id_punto_emision'];
            $arrData[$i]['id_punto_emision'] = '<button class="btn p-0 dropdown-toggle hide-arrow" onclick="openModal(' . $datos . ');" title="Ver Información del Establecimiento"><i class="menu-icon tf-icons bx bx-show"></i></button>';
            if ($arrData[$i]['estado'] == 1) {
                $arrData[$i]['estado'] = '<span class="badge badge-success" style="background: green">Activo</span>';
            } else {
                $arrData[$i]['estado'] = '<span class="badge badge-danger" style="background: red">Inactivo</span>';
            }


            $arrData[$i]['options'] = '
            <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu">
                                
                                <a class="dropdown-item" href="'.base_url().'informacion/editarEmpresa/'.$datos.'"
                                ><i class="bx bx-edit-alt me-1"></i> Editar</a
                                >
                                <a class="dropdown-item " href="#" onclick="eliminar('.$datos.');"
                                ><i class="bx bx-trash me-1"></i> Eliminar</a
                                >
                            </div>
                        </div>
            ';
        }

        echo json_encode($arrData, JSON_UNESCAPED_UNICODE);
        die();
    }
    public function crearPuntoEmision($id){

        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();

        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['idSucursal'] = $id;
        $data['tag_page'] = "Agregar Punto de Emisión";
        $data['page_title'] = "Agregar información Punto de Emisión";
        $data['page_name'] = "Agregar Pubto de Emisión";
        $this->views->getView($this, "crearPuntoEmision", $data);
    }
    public function getInfoEstablecimiento($id)
    {
        try {
            $respuesta = $this->model->selectInformacionEstablecimiento($id);
            $arrResponse = array('status' => true, 'msg' => 'OK',
                'title' => 'Correcto', 'icon' => 'success', 'data' => $respuesta);

        } catch (Exception $e) {
            $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' => 'error');
        }
        echo json_encode($arrResponse, JSON_UNESCAPED_UNICODE);
    }

    public function editarEstablecimiento($id){
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();
        $idEstablecimiento = $id;
        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['establecimiento'] = $this->model->selectInformacionEstablecimiento($idEstablecimiento);
        $data['empresa'] = $this->model->selectInformacionEmpresa($data['establecimiento']['id_empresa']);
        $data['ultimaSucursal'] = $this->model->selectCodigoEstablecimiento($data['establecimiento']['id_empresa']);
        $data['isMatriz'] = $this->model->existeMatriz($data['establecimiento']['id_empresa']);

        $data['tag_page'] = "Editar Establecimiento";
        $data['page_title'] = "Editar información Establecimiento";
        $data['page_name'] = "Editar Establecimiento";
        $this->views->getView($this, "editarEstablecimiento", $data);
    }
    public function updateEstablecimiento(){
        if($_POST){
            try {
                $this->objSucursal = new Sucursal();
                $this->objSucursal->setIdEstablecimiento($_POST['id_sucursal']);
                $this->objSucursal->setIdEmpresa($_POST['id_empresa']);
                $this->objSucursal->setCodigoSucursal($_POST['codigo_sucursal']);
                $this->objSucursal->setNombreSucursal($_POST['nombre_sucursal']);
                $this->objSucursal->setDireccionSucursal($_POST['direccion_sucursal']);
                $this->objSucursal->setNombreComercial($_POST['nombre_comercial_sucursal']);
                $this->objSucursal->setEstado(1);
                if(isset($_POST['is_matriz'])){
                    $this->objSucursal->setIsMatriz(1);
                }else{
                    $this->objSucursal->setIsMatriz(0);
                }


                $newName="";
                $archivo = $_FILES['upload']['name'];
                if (isset($archivo) && $archivo != "") {
                    $array = explode('.', $_FILES['upload']['name']);
                    $tipo = end($array);
                    $newName = "logo_Sucursal" .$this->objSucursal->getDireccionSucursal(). $this->objSucursal->getCodigoSucursal() .'.'. $tipo;
                    if(move_uploaded_file($_FILES["upload"]["tmp_name"], $_SERVER['DOCUMENT_ROOT']."/facturero/Assets/img/empresas/sucursales/logos/" . $newName)){
                        // $this->objEmpresa->setUrlFoto($newName);
                    }
                }
                $this->objSucursal->setLogoSucursal("$newName");

                $respuesta = $this->model->updateEstablecimiento($this->objSucursal);
                $this->validaciones->update($respuesta);
                $this->validaciones->validarMatriz($respuesta);

                $arrResponse = array('status' => true, 'msg' => 'Actualizado Correctamente', 'title' => 'Correcto','icon'=>'success');
            } catch (Exception $e) {
                $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' =>'error');
            }
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
        }
        die();
    }
    public function eliminarEstablecimiento($id){
        try {
            $respuesta = $this->model->eliminarEstablecimiento($id);

            $arrResponse = array('status' => true, 'msg' => 'Establecimiento Eliminado de Forma Correcta',
                'title' => 'Correcto', 'icon' => 'success', 'data' => $respuesta);

        } catch (Exception $e) {
            $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' => 'error');
        }
        echo json_encode($arrResponse, JSON_UNESCAPED_UNICODE);
    }
}