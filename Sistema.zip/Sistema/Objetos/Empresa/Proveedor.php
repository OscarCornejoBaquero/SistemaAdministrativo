<?php

class Proveedor
{
    private int $idProveedor;
    private string $razonSocial;
    private string $ruc;
    private string $email;
    private string $telefono;
    private string $telefonoSecundario;
    private string $sitioWeb;
    private int $ciudad;
    private string $direccion;
    private int  $estado;

    /**
     * @return int
     */
    public function getIdProveedor(): int
    {
        return $this->idProveedor;
    }

    /**
     * @param int $idProveedor
     */
    public function setIdProveedor(int $idProveedor): void
    {
        $this->idProveedor = $idProveedor;
    }

    /**
     * @return string
     */
    public function getRazonSocial(): string
    {
        return $this->razonSocial;
    }

    /**
     * @param string $razonSocial
     */
    public function setRazonSocial(string $razonSocial): void
    {
        $this->razonSocial = $razonSocial;
    }

    /**
     * @return string
     */
    public function getRuc(): string
    {
        return $this->ruc;
    }

    /**
     * @param string $ruc
     */
    public function setRuc(string $ruc): void
    {
        $this->ruc = $ruc;
    }

    /**
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * @param string $email
     */
    public function setEmail(string $email): void
    {
        $this->email = $email;
    }

    /**
     * @return string
     */
    public function getTelefono(): string
    {
        return $this->telefono;
    }

    /**
     * @param string $telefono
     */
    public function setTelefono(string $telefono): void
    {
        $this->telefono = $telefono;
    }

    /**
     * @return string
     */
    public function getTelefonoSecundario(): string
    {
        return $this->telefonoSecundario;
    }

    /**
     * @param string $telefonoSecundario
     */
    public function setTelefonoSecundario(string $telefonoSecundario): void
    {
        $this->telefonoSecundario = $telefonoSecundario;
    }

    /**
     * @return string
     */
    public function getSitioWeb(): string
    {
        return $this->sitioWeb;
    }

    /**
     * @param string $sitioWeb
     */
    public function setSitioWeb(string $sitioWeb): void
    {
        $this->sitioWeb = $sitioWeb;
    }

    /**
     * @return int
     */
    public function getCiudad(): int
    {
        return $this->ciudad;
    }

    /**
     * @param int $ciudad
     */
    public function setCiudad(int $ciudad): void
    {
        $this->ciudad = $ciudad;
    }

    /**
     * @return string
     */
    public function getDireccion(): string
    {
        return $this->direccion;
    }

    /**
     * @param string $direccion
     */
    public function setDireccion(string $direccion): void
    {
        $this->direccion = $direccion;
    }

    /**
     * @return int
     */
    public function getEstado(): int
    {
        return $this->estado;
    }

    /**
     * @param int $estado
     */
    public function setEstado(int $estado): void
    {
        $this->estado = $estado;
    }


}