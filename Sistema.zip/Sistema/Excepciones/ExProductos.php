<?php

class ExProductos extends Controllers
{
    public function storeCategoria($request_proveedor){
        if($request_proveedor == 'Categoria Existe'){
            throw new Exception('ERROR AL MOMENTO DE CREAR LA CATEGORIA. !YA EXISTE');
        }
        return true;
    }
}