<?php

class User
{
    private string $username;
    private string $email;
    private string $password;
    private string $terminos;
    private int $id_rol;
    private int $estado;
    private string $nombres;
    private string $apellidos;
    private int $genero;
    private string $identificacion;
    private string $email2;
    private string $celular;
    private string $convencional;
    private string $direccion;
    private string $urlFoto;
    private int $idUser;

    public function __construct()
    {
    }

    /**
     * @return int
     */
    public function getIdUser(): int
    {
        return $this->idUser;
    }

    /**
     * @param int $idUser
     */
    public function setIdUser(int $idUser): void
    {
        $this->idUser = $idUser;
    }

    /**
     * @return string
     */
    public function getUsername(): string
    {
        return $this->username;
    }

    /**
     * @param string $username
     */
    public function setUsername(string $username): void
    {
        $this->username = $username;
    }

    /**
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * @param string $email
     */
    public function setEmail(string $email): void
    {
        $this->email = $email;
    }

    /**
     * @return string
     */
    public function getPassword(): string
    {
        return $this->password;
    }

    /**
     * @param string $password
     */
    public function setPassword(string $password): void
    {
        $this->password = $password;
    }

    /**
     * @return string
     */
    public function getTerminos(): string
    {
        return $this->terminos;
    }

    /**
     * @param string $terminos
     */
    public function setTerminos(string $terminos): void
    {
        $this->terminos = $terminos;
    }

    /**
     * @return int
     */
    public function getIdRol(): int
    {
        return $this->id_rol;
    }

    /**
     * @param int $id_rol
     */
    public function setIdRol(int $id_rol): void
    {
        $this->id_rol = $id_rol;
    }

    /**
     * @return int
     */
    public function getEstado(): int
    {
        return $this->estado;
    }

    /**
     * @param int $estado
     */
    public function setEstado(int $estado): void
    {
        $this->estado = $estado;
    }

    /**
     * @return string
     */
    public function getNombres(): string
    {
        return $this->nombres;
    }

    /**
     * @param string $nombres
     */
    public function setNombres(string $nombres): void
    {
        $this->nombres = $nombres;
    }

    /**
     * @return string
     */
    public function getApellidos(): string
    {
        return $this->apellidos;
    }

    /**
     * @param string $apellidos
     */
    public function setApellidos(string $apellidos): void
    {
        $this->apellidos = $apellidos;
    }

    /**
     * @return int
     */
    public function getGenero(): int
    {
        return $this->genero;
    }

    /**
     * @param int $genero
     */
    public function setGenero(int $genero): void
    {
        $this->genero = $genero;
    }

    /**
     * @return string
     */
    public function getIdentificacion(): string
    {
        return $this->identificacion;
    }

    /**
     * @param string $identificacion
     */
    public function setIdentificacion(string $identificacion): void
    {
        $this->identificacion = $identificacion;
    }

    /**
     * @return string
     */
    public function getEmail2(): string
    {
        return $this->email2;
    }

    /**
     * @param string $email2
     */
    public function setEmail2(string $email2): void
    {
        $this->email2 = $email2;
    }

    /**
     * @return string
     */
    public function getCelular(): string
    {
        return $this->celular;
    }

    /**
     * @param string $celular
     */
    public function setCelular(string $celular): void
    {
        $this->celular = $celular;
    }

    /**
     * @return string
     */
    public function getConvencional(): string
    {
        return $this->convencional;
    }

    /**
     * @param string $convencional
     */
    public function setConvencional(string $convencional): void
    {
        $this->convencional = $convencional;
    }

    /**
     * @return string
     */
    public function getDireccion(): string
    {
        return $this->direccion;
    }

    /**
     * @param string $direccion
     */
    public function setDireccion(string $direccion): void
    {
        $this->direccion = $direccion;
    }

    /**
     * @return string
     */
    public function getUrlFoto(): string
    {
        return $this->urlFoto;
    }

    /**
     * @param string $urlFoto
     */
    public function setUrlFoto(string $urlFoto): void
    {
        $this->urlFoto = $urlFoto;
    }

}