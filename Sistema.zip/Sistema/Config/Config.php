<?php
//Direccion del sistema 
const BASE_URL = "http://ec2-3-88-43-169.compute-1.amazonaws.com/facturero/";

//Zona horaria 
date_default_timezone_set('America/Guayaquil');

//Datos de Conexion con la Base de datos mysql
const DB_SERVIDOR = "localhost";
const DB_BASE_DATOS= "facturacionmacrogram";
const DB_USUARIO= "ocornejo";
const DB_PASSWORD = "macrogram";
const DB_CHARSET = "charset=utf8";
const DB_PUERTO = "53848";
/*
//Datos de Conexion con la Base de datos SQL SERVER
const DB_SERVIDOR = "107.180.75.55\SQLEXPRESS";
const DB_BASE_DATOS= "FACTURERO_MACRO";
const DB_USUARIO= "sa";
const DB_PASSWORD = "+-*MACROadmin";
const DB_CHARSET = "charset=utf8";
const DB_PUERTO = "53848";*/
//Variable decimal y millar ejemplo 31,1111.00
const SPD = ".";
const SPM = ",";

//Simbolo moneda 
const SMONEY = "$";

?>