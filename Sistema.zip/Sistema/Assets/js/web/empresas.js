var tableEmpresas;
function requestAll(){
    return  request = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
}
document.addEventListener('DOMContentLoaded', function(){

    tableEmpresas = $('#tableEmpresas').DataTable( {
        "aProcessing":true,
        "aServerSide":true,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
        },
        "ajax":{
            "url": " "+base_url+"informacion/getAll",
            "dataSrc":""
        },
        "columns":[
            {"data":"id_empresa"},
            {"data":"ruc_empresa"},
            {"data":"razon_social_empresa"},
            {"data":"nombre_comerial_empresa"},
            {"data":"acciones"},
            {"data":"estado"},
            {"data":"options"}
        ],
        'dom': 'Bfrtip',

        'buttons': [
            {
                "extend": "copyHtml5",
                "text": "<i class='far fa-copy'></i> Copiar",
                "titleAttr":"Copiar",
                "className": "btn btn-secondary"
            },{
                "extend": "excelHtml5",
                "text": "<i class='fas fa-file-excel'></i> Excel",
                "titleAttr":"Esportar a Excel",
                "className": "btn btn-success"
            },{
                "extend": "pdfHtml5",
                "text": "<i class='fas fa-file-pdf'></i> PDF",
                "titleAttr":"Esportar a PDF",
                "className": "btn btn-danger"
            }
        ],
        "resonsieve":"true",
        "bDestroy": true,
        "autoFill": true,
        "iDisplayLength": 10,
        "order":[[0,"acs"]]
    });

}, false);

function openModal(data)
{
    var ajaxUrl = base_url+'informacion/getInfoEmpresa/'+data;
    $.ajax({
        type: 'get',
        url: ajaxUrl,
        data: data,
        cache:false,
        contentType: false,
        processData: false,
        beforeSend: function(){
        },
        complete:function(data){
        },
        success: function(data){
                var objData = JSON.parse(data);
            var data = objData.data;
            console.log(data);
            $('#titleEmpresa').text("Empresa"+" "+data['nombre_comerial_empresa']);
            $('#id_empresa').val(data['id_empresa']);
            $('#razonSocial').text(data['razon_social_empresa']);
            $('#ruc').text(data['ruc_empresa']);
            $('#correo').text(data['correo_empresa']);
            $('#telefono').text(data['telefono_empresa']);
            $('#direccion').text(data['direccion_empresa']);
            $('#tipo_contribuyente').text(data['id_tipo_contribuyente']);
            $('#agente_retencion').text(data['agente_retencion']);
            $('#contribuyente_especial').text(data['contribuyente_especial']);
            $('#codigo_artesano').text(data['codigo_artesano']);
            $('#nombre_recibos').text(data['nombre_recibos']);
            $('#contabilidad').text(data['lleva_contabilidad']);

            if(data['logo_empresa'] == null || data['logo_empresa'] == "null"){
                $('#logoEmpresa').prop('src',base_url+'Assets/img/empresas/logos/default.jpg');
            }else{
                $('#logoEmpresa').prop('src',base_url+'Assets/img/empresas/logos/'+data['logo_empresa']);
            }
            $('#modalEmpresa').modal('show');
        },
        error: function(data){
            Swal.fire({
                title: 'Error',
                text: 'Problemas al procesar la consulta',
                icon: 'error',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
            }).then((result) => {
                location.reload();
            })
        }
    });

}
function editarEmpresa(){
    idEmpresa = $('#id_empresa').val();
   console.log(idEmpresa);
    window.location.href = '../../facturero/informacion/editarEmpresa/'+idEmpresa;
}
function addImage(e) {
    var file = e.target.files[0],
        imageType = /image.*/;
    if (!file.type.match(imageType)) {
        Swal.fire('Hey', 'El formato no es el correcto', 'warning');
    } else {
        var reader = new FileReader();
        reader.onload = fileOnload;
        reader.readAsDataURL(file);
        return;
    }
}
function fileOnload(e) {
    var result = e.target.result;
    $('#uploadLogo').attr("src", result);
}

$('#upload').change(function(e) {
    previa = "uploadLogo";
    addImage(e);
});



$(document).ready(function () {
    $("#formEditarEmpresa").bind("submit", function (e) {
       /* if (validarRegistro()) {
            e.preventDefault();
            Swal.fire({
                title: 'Error en datos del Usuario ',
                text: 'Debe de Ingresar datos para el registro',
                icon: 'error',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
            }).then((result) => {
                location.reload();
            })
       // } else {*/
            // Capturamnos el boton de envío
            var btnEnviar = $("#btn-enviar");
            var formData = new FormData(this);
            console.log(formData);
            $.ajax({
                type: $(this).attr("method"),
                url: $(this).attr("action"),
                // data:$(this).serialize(),
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function () {
                    /*
                    * Esta función se ejecuta durante el envió de la petición al
                    * servidor.
                    * */
                    btnEnviar.val("Enviando"); // Para input de tipo button
                    btnEnviar.attr("disabled", "disabled");
                },
                complete: function (data) {
                    /*
                    * Se ejecuta al termino de la petición
                    * */
                    btnEnviar.val("Enviar formulario");
                    btnEnviar.removeAttr("disabled");
                },
                success: function (data) {
                    /*
                    * Se ejecuta cuando termina la petición y esta ha sido
                    * correcta
                    * */
                    var objData = JSON.parse(data);
                    var respuesta = objData.msg;
                    var title = objData.title;
                    var icon = objData.icon;
                    console.log(objData);
                    Swal.fire({
                        title: title,
                        text: respuesta,
                        icon: icon,
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        if (title != "Error") {
                           window.location.href = '../../informacion/empresas'
                        } else {
                            location.reload();
                        }

                    })
                },
                error: function (data) {
                    /*
                    * Se ejecuta si la peticón ha sido erronea
                    * */
                    Swal.fire({
                        title: 'Error',
                        text: 'Problemas al tratar de enviar el formulario',
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        location.reload();
                    })
                }
            });
       // }
        // Nos permite cancelar el envio del formulario
        return false;
    });
});
$(document).ready(function () {
    $("#formCrearEmpresa").bind("submit", function (e) {
        /* if (validarRegistro()) {
             e.preventDefault();
             Swal.fire({
                 title: 'Error en datos del Usuario ',
                 text: 'Debe de Ingresar datos para el registro',
                 icon: 'error',
                 showCancelButton: false,
                 confirmButtonColor: '#3085d6',
             }).then((result) => {
                 location.reload();
             })
        // } else {*/
        // Capturamnos el boton de envío
        var btnEnviar = $("#btn-enviar");
        var formData = new FormData(this);
        console.log(formData);
        $.ajax({
            type: $(this).attr("method"),
            url: $(this).attr("action"),
            // data:$(this).serialize(),
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            beforeSend: function () {
                /*
                * Esta función se ejecuta durante el envió de la petición al
                * servidor.
                * */
                btnEnviar.val("Enviando"); // Para input de tipo button
                btnEnviar.attr("disabled", "disabled");
            },
            complete: function (data) {
                /*
                * Se ejecuta al termino de la petición
                * */
                btnEnviar.val("Almacenando Empresa");
                btnEnviar.removeAttr("disabled");
            },
            success: function (data) {
                /*
                * Se ejecuta cuando termina la petición y esta ha sido
                * correcta
                * */
                var objData = JSON.parse(data);
                var respuesta = objData.msg;
                var title = objData.title;
                var icon = objData.icon;
                console.log(objData);
                Swal.fire({
                    title: title,
                    text: respuesta,
                    icon: icon,
                    showCancelButton: false,
                    confirmButtonColor: '#3085d6',
                }).then((result) => {
                    if (title != "Error") {
                        window.location.href = '../../facturero/informacion/empresas'
                    } else {
                        location.reload();
                    }

                })
            },
            error: function (data) {
                /*
                * Se ejecuta si la peticón ha sido erronea
                * */
                Swal.fire({
                    title: 'Error',
                    text: 'Problemas al tratar de enviar el formulario',
                    icon: 'error',
                    showCancelButton: false,
                    confirmButtonColor: '#3085d6',
                }).then((result) => {
                    location.reload();
                })
            }
        });
        // }
        // Nos permite cancelar el envio del formulario
        return false;
    });
});
function eliminar(id){
    Swal.fire({
        title: 'Esta Seguro que desea Eliminar la Empresa?',
        text: "Recuerde que esta Operación es Irreversible y afectara a las sucursales que tiene la empresa. ",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si Eliminar Empresa'
    }).then((result) => {
        if (result.isConfirmed) {
            var ajaxUrl = base_url+'informacion/eliminarEmpresa/'+id;
            $.ajax({
                type: 'get',
                url: ajaxUrl,
                data: id,
                cache: false,
                contentType: false,
                processData: false,
                success: function (data) {
                    /*
                    * Se ejecuta cuando termina la petición y esta ha sido
                    * correcta
                    * */
                    var objData = JSON.parse(data);
                    var respuesta = objData.msg;
                    var title = objData.title;
                    var icon = objData.icon;
                    console.log(objData);
                    Swal.fire({
                        title: title,
                        text: respuesta,
                        icon: icon,
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        if (title != "Error") {
                            window.location.href = '../../facturero/informacion/empresas'
                        } else {
                            location.reload();
                        }

                    })
                },
                error: function (data) {
                    /*
                    * Se ejecuta si la peticón ha sido erronea
                    * */
                    Swal.fire({
                        title: 'Error',
                        text: 'Problemas al tratar de eliminar la empresa.',
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        location.reload();
                    })
                }
            });

        }
    })
}
function mostrarPassword(){
    var cambio = document.getElementById("pass_firma_electronica");
    if(cambio.type == "password"){
        cambio.type = "text";
      $('.icon').removeClass('bx bx-hide').addClass('bx bx-show');
    }else{
        cambio.type = "password";
        $('.icon').removeClass('bx bx-show').addClass('bx bx-hide');
    }
}