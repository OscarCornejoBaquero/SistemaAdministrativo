<header>
    <div class="container">
        <div class="row">
            <div class="col-md-7 encabezado_logo">
                <img class="logo" src="../archivos/img/logoFEF.png">
                <h1 class="tituWeb"></h1>
                <h1>Federacion de Arbritos</h1>
            </div>
            <div class="col-md-5 encabezado_logo">
                <div class="encabezado_opciones fecha">
                    <p>Guayaquil</p>
                    <p>Fecha Mes dia y año actual</p>
                </div>
                <span>|</span>
                <div class="encabezado_opciones">
                    <p>Usuario</p>
                    <p>Grupo 2 </p>
                </div>
                <span>|</span>
                <div class="encabezado_opciones">
                    <p></p>
                    <a href="#">Cerrar Sesion <p>
                            <i class="fas fa-sign-out-alt"></i>
                        </p></a>
                </div>
            </div>
        </div>
    </div>

    <div class="contenedor">
        <?php
            require_once "nav.php";
        ?>
    </div>
</header>