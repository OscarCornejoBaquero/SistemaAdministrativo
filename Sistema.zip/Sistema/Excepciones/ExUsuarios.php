<?php
require_once ("Objetos/Login/User.php");
class ExUsuarios extends Controllers
{
    private User $objUsuario;
    public $mensaje;
    public function __construct()
    {
        parent::__construct();
    }
    public function usuarioExistente($request_user){
        if($request_user == 'NO Existe'){
            throw new Exception('ERROR EL USUARIO QUE DESEA ACTUALIZAR NO EXISTE.');
        }
        return true;
    }
}