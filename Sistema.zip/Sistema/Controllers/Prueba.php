<?php

class Prueba extends Controllers
{
    public function __construct()
    {
        parent::__construct();
    }
    public function prueba(){
        $data['tag_page'] = "Prueba";
        $data['page_title'] = "prueba de funcionabilidad ";
        $data['page_name'] = "prueba";
        $this->views->getView($this,"prueba",$data);
    }
}