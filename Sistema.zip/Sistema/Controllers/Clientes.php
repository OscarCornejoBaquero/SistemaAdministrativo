<?php
require_once("Models/NavModel.php");
require_once("Models/InformaciongeneralModel.php");
require_once("Models/Crud.php");
class Clientes extends Controllers implements Crud
{

    public function getDataTable()
    {
        // TODO: Implement getDataTable() method.
    }

    public function show($id)
    {
        // TODO: Implement show() method.
    }

    public function create()
    {
        // TODO: Implement create() method.
    }

    public function store()
    {
        // TODO: Implement store() method.
    }

    public function edit($id)
    {
        // TODO: Implement edit() method.
    }

    public function update()
    {
        // TODO: Implement update() method.
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
    }
}