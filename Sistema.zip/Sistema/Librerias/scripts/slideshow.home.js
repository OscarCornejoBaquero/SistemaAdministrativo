    
    <script>
    $('.carousel').carousel();
</script>  