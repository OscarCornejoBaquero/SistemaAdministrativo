<?php

class ExProveedores extends Controllers
{
    public function __construct()
    {
        parent::__construct();
    }
    public function store($request_proveedor){
        if($request_proveedor == 'Proveedor Existe'){
            throw new Exception('ERROR AL MOMENTO DE CREAR el PROVEEDOR. !YA EXISTE');
        }
        return true;
    }
}