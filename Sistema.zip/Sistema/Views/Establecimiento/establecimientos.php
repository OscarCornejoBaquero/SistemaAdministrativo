<?php
headers($data);
?>

<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"> Datos Tributarios /</span> <?php echo $data['tag_page']?></h4>

    <!-- Basic Bootstrap Table -->
    <div class="card">
        <div class="row">
            <div class="col-9 card-header">
                <h5 class="card-header" ><?php echo $data['tag_page'] ?></h5>
            </div>
            <input type="hidden" name="id_empresa" id="id_empresa" value="<?php echo $data['idEmpresa']?>">
            <div class="col-sm-12 col-lg-3  card-header">
                <a type="button" class="btn btn-outline-warning " href="<?php echo base_url()?>establecimiento/crearSucursal/<?php echo $data['idEmpresa']?>" style="color: black" title="Agregar Empresa">
                    <span class="tf-icons bx bx-plus" ></span>&nbsp; Establecimiento
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive ">
                <table class="table table-striped" id="tableEstablecimientos">
                    <thead>
                    <tr>
                        <th>INFORMACIÓN</th>
                        <th>EMPRESA</th>
                        <th>NOMBRE ESTABLECIMIENTO</th>
                        <th>CÓDIGO ESTABLECIMIENTO</th>
                        <th>ACCIONES</th>
                        <th>ESTADO</th>

                        <th>OPCIONES</th>
                    </tr>
                    </thead>
                    <tbody >

                    </tbody>
                </table>
            </div>
        </div>
    </div>


</div>

<?php
scripts($data);
?>
<script src="<?php echo media()?>/js/web/establecimientosEmpresa.js"></script>
<?php
fin();
?>

