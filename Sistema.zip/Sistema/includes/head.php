<!--Declaración Meta para que el documento pueda ser visto en diferentes navegadores-->
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximun-scale=1.0, 
	minumun-scale=1.0">
<!--Llamado a los diferentes estilos que daran forma a las páginas-->
<link rel="stylesheet" href="../sistema/librerias/css/estilosSistema/bootstrap.min.css">
<link rel="icon" type="image/png" href="../archivos/img/icono.png" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
    integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<link rel="stylesheet" href="../sistema/librerias/css/estilosSistema/style.css">
<link rel="stylesheet" href="../sistema/librerias/css/estilosSistema/home.css">
<link rel="stylesheet" href="../sistema/librerias/css/estilosSistema/normalize.css">
<title>Federación de Arbritos</title>