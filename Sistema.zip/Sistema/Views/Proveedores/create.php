<?php
headers($data);
?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"> Agentes Externos /</span> <?php echo $data['tag_page']?></h4>
    <div class="col-xxl">
        <div class="card mb-8">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="mb-0"><?php echo $data['page_name'] ?></h5>
                <small class="text-muted float-end">La información ingresada sera utilizada para la creación de productos</small>
            </div>
            <div class="card-body">
                <form id="formCrearProveedor" name="proveedor" method="POST" action="<?php echo base_url()?>proveedores/store" enctype="multipart/formdata" >
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="basic-icon-default-fullname">Razón Social <span class="requerido">*</span></label>
                        <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <span id="fullname2" class="input-group-text"><i class="bx bx-user"></i></span>
                                <input type="text" class="form-control" id="fullname" name="fullname" placeholder="Nombres Completos" aria-label="fullname" aria-describedby="fullname">
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="basic-icon-default-company">Ruc <span class="requerido">*</span></label>
                        <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <span id="ruc2" class="input-group-text"><i class="bx bx-buildings"></i></span>
                                <input type="text" id="ruc" name="ruc" class="form-control" minlength="10" maxlength="13"placeholder="0909090909001" aria-label="ruc" aria-describedby="ruc">
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="basic-icon-default-email">Email <span class="requerido">*</span></label>
                        <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="bx bx-envelope"></i></span>
                                <input type="email" id="email" name="email" class="form-control" placeholder="correo electronico" aria-label="correo electronico" aria-describedby="email">
                            </div>

                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 form-label" for="basic-icon-default-phone">Teléfono Principal <span class="requerido">*</span></label>
                        <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <span id="telefono2" class="input-group-text"><i class="bx bx-phone"></i></span>
                                <input type="text" id="telefono1" name="telefono1" minlength="10" maxlength="10" class="form-control phone-mask" placeholder="0909090909" aria-label="09090909090" aria-describedby="telefono2">
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 form-label" for="basic-icon-default-phone">Teléfono Secundario</label>
                        <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <span id="telefono3" class="input-group-text"><i class="bx bx-phone"></i></span>
                                <input type="text" id="telefono2" name="telefono2" minlength="10" maxlength="10" class="form-control phone-mask" placeholder="0909090909" aria-label="09090909090" aria-describedby="telefono3">
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 form-label" for="basic-icon-default-phone">Sitio Web</label>
                        <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <span id="sitio_web2" class="input-group-text"><i class="bx bx-globe"></i></span>
                                <input type="text" id="sitio_web" name="sitio_web" class="form-control phone-mask" placeholder="www.sitioweb.com" aria-label="www.sitioweb.com" aria-describedby="sitio_web2">
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 form-label" for="basic-icon-default-phone"></label>
                        <div class="col-md-10">
                            <div class="row">
                                <div class="col-md-6">
                                    <label class=" form-label" for="basic-icon-default-phone">Provincia <span class="requerido">*</span></label>
                                    <div class="input-group input-group-merge">
                                        <select class="js-example-basic-single " name="provincia" id="provincia">
                                            <option >Seleccione</option>
                                            <?php
                                            foreach ($data['provincias'] as $provincias){
                                                ?>
                                                <option value="<?php echo $provincias['cod_provincia'] ?>"><?php echo $provincias['nombre_provincia'] ?></option>

                                            <?php }?>

                                        </select>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <label class=" form-label" for="basic-icon-default-phone">Ciudad <span class="requerido">*</span></label>
                                    <div class="input-group input-group-merge">
                                        <select class="js-example-basic-single " name="ciudad" id="ciudad">
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 form-label" for="basic-icon-default-message">Dirección <span class="requerido">*</span></label>
                        <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <span id="direccion2" class="input-group-text"><i class="bx bx-book-bookmark"></i></span>
                                <textarea id="direccion" name="direccion" class="form-control" placeholder="Detalle su dirección Completa" aria-label="Dirección Completa" aria-describedby="direccion"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 form-label" for="basic-icon-default-message">Proveedor Activo? </label>
                        <div class="col-sm-10">
                            <div class="form-check form-switch mb-2">

                                <input class="form-check-input" type="checkbox" id="estado" name="estado" checked="">

                            </div>
                        </div>
                    </div>

                    <div class="row justify-content-end">
                        <div class="col-sm-10">
                            <button type="submit" id="btn-enviar" class="btn btn-primary">Guardar Proveedor</button>
                            <a  href="<?php echo base_url()?>proveedores" class="btn btn-danger">Cancelar</a>
                        </div>
                    </div>


                </form>
            </div>
        </div>
    </div>
</div>


<?php
scripts($data);
?>
<script src="<?php echo media()?>/js/web/proveedores.js"></script>
<?php
fin();
?>
