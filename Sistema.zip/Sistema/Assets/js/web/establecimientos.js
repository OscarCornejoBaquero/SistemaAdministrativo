var tableEstablecimientos;
function requestAll(){
    return  request = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
}
document.addEventListener('DOMContentLoaded', function(){

    tableEstablecimientos = $('#tableEstablecimientos').DataTable( {
        "aProcessing":true,
        "aServerSide":true,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
        },
        "ajax":{
            "url": " "+base_url+"establecimiento/getAll",
            "dataSrc":""
        },
        "columns":[
            {"data":"id_sucursal"},
            {"data":"nombre_comerial_empresa"},
            {"data":"nombre_sucursal"},
            {"data":"codigo_sucursal"},
            {"data":"acciones"},
            {"data":"estadoSucursal"},

            {"data":"options"}
        ],
        'dom': 'Bfrtip',

        'buttons': [
            {
                "extend": "copyHtml5",
                "text": "<i class='far fa-copy'></i> Copiar",
                "titleAttr":"Copiar",
                "className": "btn btn-secondary"
            },{
                "extend": "excelHtml5",
                "text": "<i class='fas fa-file-excel'></i> Excel",
                "titleAttr":"Esportar a Excel",
                "className": "btn btn-success"
            },{
                "extend": "pdfHtml5",
                "text": "<i class='fas fa-file-pdf'></i> PDF",
                "titleAttr":"Esportar a PDF",
                "className": "btn btn-danger"
            }
        ],
        "resonsieve":"true",
        "bDestroy": true,
        "autoFill": true,
        "iDisplayLength": 10,
        "order":[[0,"acs"]]
    });

}, false);
