<?php

class Empresa
{
    /**
     * @var int
     */
    private int $id_empresa;
    /**
     * @var string
     */
    private string $idUser;
    /**
     * @var string
     */
    private string $ruc;
    /**
     * @var string
     */
    private string $razonSocial;
    /**
     * @var string
     */
    private string $nombreComercial;
    /**
     * @var string
     */
    private string $correo;
    /**
     * @var string
     */
    private string $telefono;
    /**
     * @var string
     */
    private string $logo;
    /**
     * @var int
     */
    private int $tipoContribuyente;
    /**
     * @var string
     */
    private string $direccion;
    /**
     * @var string
     */
    private string $llevaContabilidad;
    /**
     * @var string
     */
    private string $agenteRetencion;
    /**
     * @var string
     */
    private string $contribuyenteEspecial;
    /**
     * @var string
     */
    private string $nombreRecibos;
    /**
     * @var string
     */
    private string $firma;
    /**
     * @var string
     */
    private string $passFirma;
    /**
     * @var int
     */
    private int $estado;
    /**
     * @var string
     */
    private string $codigoArtesano;


    /**
     *
     */
    public function __construct()
    {
    }

    /**
     * @return string
     */
    public function getIdUser(): string
    {
        return $this->idUser;
    }

    /**
     * @param string $idUser
     */
    public function setIdUser(string $idUser): void
    {
        $this->idUser = $idUser;
    }

    /**
     * @return string
     */
    public function getCodigoArtesano(): string
    {
        return $this->codigoArtesano;
    }

    /**
     * @param string $codigoArtesano
     */
    public function setCodigoArtesano(string $codigoArtesano): void
    {
        $this->codigoArtesano = $codigoArtesano;
    }

    /**
     * @return int
     */
    public function getIdEmpresa(): int
    {
        return $this->id_empresa;
    }

    /**
     * @param int $id_empresa
     */
    public function setIdEmpresa(int $id_empresa): void
    {
        $this->id_empresa = $id_empresa;
    }

    /**
     * @return int
     */
    public function getEstado(): int
    {
        return $this->estado;
    }

    /**
     * @param int $estado
     */
    public function setEstado(int $estado): void
    {
        $this->estado = $estado;
    }

    /**
     * @return string
     */
    public function getLogo(): string
    {
        return $this->logo;
    }

    /**
     * @param string $logo
     */
    public function setLogo(string $logo): void
    {
        $this->logo = $logo;
    }

    /**
     * @return string
     */
    public function getRuc(): string
    {
        return $this->ruc;
    }

    /**
     * @param string $ruc
     */
    public function setRuc(string $ruc): void
    {
        $this->ruc = $ruc;
    }

    /**
     * @return string
     */
    public function getRazonSocial(): string
    {
        return $this->razonSocial;
    }

    /**
     * @param string $razonSocial
     */
    public function setRazonSocial(string $razonSocial): void
    {
        $this->razonSocial = $razonSocial;
    }

    /**
     * @return string
     */
    public function getNombreComercial(): string
    {
        return $this->nombreComercial;
    }

    /**
     * @param string $nombreComercial
     */
    public function setNombreComercial(string $nombreComercial): void
    {
        $this->nombreComercial = $nombreComercial;
    }

    /**
     * @return string
     */
    public function getCorreo(): string
    {
        return $this->correo;
    }

    /**
     * @param string $correo
     */
    public function setCorreo(string $correo): void
    {
        $this->correo = $correo;
    }

    /**
     * @return string
     */
    public function getTelefono(): string
    {
        return $this->telefono;
    }

    /**
     * @param string $telefono
     */
    public function setTelefono(string $telefono): void
    {
        $this->telefono = $telefono;
    }

    /**
     * @return int
     */
    public function getTipoContribuyente(): int
    {
        return $this->tipoContribuyente;
    }

    /**
     * @param int $tipoContribuyente
     */
    public function setTipoContribuyente(int $tipoContribuyente): void
    {
        $this->tipoContribuyente = $tipoContribuyente;
    }

    /**
     * @return string
     */
    public function getDireccion(): string
    {
        return $this->direccion;
    }

    /**
     * @param string $direccion
     */
    public function setDireccion(string $direccion): void
    {
        $this->direccion = $direccion;
    }

    /**
     * @return string
     */
    public function getLlevaContabilidad(): string
    {
        return $this->llevaContabilidad;
    }

    /**
     * @param string $llevaContabilidad
     */
    public function setLlevaContabilidad(string $llevaContabilidad): void
    {
        $this->llevaContabilidad = $llevaContabilidad;
    }

    /**
     * @return string
     */
    public function getAgenteRetencion(): string
    {
        return $this->agenteRetencion;
    }

    /**
     * @param string $agenteRetencion
     */
    public function setAgenteRetencion(string $agenteRetencion): void
    {
        $this->agenteRetencion = $agenteRetencion;
    }

    /**
     * @return string
     */
    public function getContribuyenteEspecial(): string
    {
        return $this->contribuyenteEspecial;
    }

    /**
     * @param string $contribuyenteEspecial
     */
    public function setContribuyenteEspecial(string $contribuyenteEspecial): void
    {
        $this->contribuyenteEspecial = $contribuyenteEspecial;
    }

    /**
     * @return string
     */
    public function getNombreRecibos(): string
    {
        return $this->nombreRecibos;
    }

    /**
     * @param string $nombreRecibos
     */
    public function setNombreRecibos(string $nombreRecibos): void
    {
        $this->nombreRecibos = $nombreRecibos;
    }

    /**
     * @return string
     */
    public function getFirma(): string
    {
        return $this->firma;
    }

    /**
     * @param string $firma
     */
    public function setFirma(string $firma): void
    {
        $this->firma = $firma;
    }

    /**
     * @return string
     */
    public function getPassFirma(): string
    {
        return $this->passFirma;
    }

    /**
     * @param string $passFirma
     */
    public function setPassFirma(string $passFirma): void
    {
        $this->passFirma = $passFirma;
    }

}