<?php

class ExEstablecimiento extends Controllers
{
    public function __construct()
    {
        parent::__construct();
    }
    public function update($request_user){
        if($request_user == 'fallo'){
            throw new Exception('ERROR LA EMPRESA SELECCIONADA TIENE UN PROBLEMA AL ACTUALIZAR INTENTELO MAS TARDE.');
        }
        return true;
    }
    public function store($request_user){
        if($request_user == 'Establecimiento Existe'){
            throw new Exception('ERROR AL MOMENTO DE CREAR el Establecimiento. !YA EXISTE');
        }
        return true;
    }
    public function validarMatriz($request_user){
        if($request_user == 'Error en Matriz'){
            throw new Exception('ERROR, NO SE PUEDE ACTUALIZAR ESTE ESTABLECIMIENTO A MATRIZ, DEBIDO A QUE YA EXISTE 
            OTRA MATRIZ ACTIVA. DESACTIVELA Y VUELVA A INTENTARLO');
        }
        return true;
    }
}