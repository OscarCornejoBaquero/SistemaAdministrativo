<?php

interface Crud
{
    public function getDataTable();
    public function show($id);
    public function create();
    public function store();
    public function edit($id);
    public function update();
    public function delete($id);
}