<?php
headers($data);

?>


<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Datos Tributarios / Establecimientos / </span> <?php echo $data['tag_page']?></h4>

    <div class="row">
        <div class="col-md-12">
            <ul class="nav nav-pills flex-column flex-md-row mb-3">
                <li class="nav-item">
                    <a class="nav-link active" href="javascript:void(0);"><i class="bx bx-user me-1"></i> Información del Establecimiento</a>
                </li>
            </ul>
            <div class="card mb-4">
                <div class="card-body">
                    <form id="formCrearEstablecimiento" method="POST" action="<?php echo base_url()?>establecimiento/updateEstablecimiento" enctype="multipart/formdata" >
                        <div class="card-body">
                            <input type="hidden" name="idUser" id="idUser" value="<?php $_SESSION['id_user'] ?>">
                            <div class="d-flex align-items-start align-items-sm-center gap-4">

                                <img
                                    src="<?php echo media()?>/img/empresas/sucursales/logos/<?php echo $data['establecimiento']['logo_sucursal']?>"
                                    alt="user-avatar"
                                    class="d-block rounded circlarImagen"
                                    height="200"
                                    width="200"
                                    id="uploadLogo"

                                />
                                <div class="button-wrapper">
                                    <label for="upload" class="btn btn-primary me-2 mb-4" tabindex="0">
                                        <span class="d-none d-sm-block">Agregar Logo</span>
                                        <i class="bx bx-upload d-block d-sm-none"></i>
                                        <input
                                            type="file"
                                            id="upload"
                                            name="upload"
                                            hidden
                                            class="account-file-input"
                                            accept="image/png, image/jpeg"
                                        />
                                    </label>
                                    <button type="reset" class="btn btn-outline-secondary account-image-reset mb-4">
                                        <i class="bx bx-reset d-block d-sm-none"></i>
                                        <span class="d-none d-sm-block">Limpiar Datos </span>
                                    </button>

                                    <p class="text-muted mb-0">Solo se aceptan Imágenes JPG, GIF or PNG. Tamaño máximo de 1mb</p>
                                </div>
                            </div>
                        </div>
                        <hr class="my-0" />
                        <input type="hidden" name="id_empresa" id="id_empresa" value="<?php echo $data['empresa']['id_empresa'] ?>">
                        <input type="hidden" name="id_sucursal" id="id_sucursal" value=" <?php echo $data['establecimiento']['id_sucursal'] ?>">
                        <div class="row">
                            <div class="mb-3 col-md-4">
                                <label for="ruc_empresa" class="form-label">Ruc-Empresa</label>

                                <input
                                    class="form-control"
                                    type="text" disabled
                                    value="<?php echo $data['empresa']['ruc_empresa'] ?>" placeholder="Razón Social (Nombre Completo)"/>
                            </div>
                            <div class="mb-3 col-md-4">
                                <label for="ruc_empresa" class="form-label">Razón Social</label>

                                <input
                                    class="form-control"
                                    type="text" disabled
                                    value="<?php echo $data['empresa']['razon_social_empresa'] ?>" placeholder="Razón Social (Nombre Completo)"/>
                            </div>

                            <div class="mb-3 col-md-4">
                                <label for="nombre_comerial_empresa" class="form-label">Nombre Comercial</label>
                                <input
                                    class="form-control" disabled
                                    type="text"
                                    value="<?php echo $data['empresa']['nombre_comerial_empresa'] ?>" placeholder="Nombre Comercial (Como se llama su Negocio)" />
                            </div>
                            <div class="mb-3 col-md-3">
                                <label for="correo_empresa" class="form-label">Código del Establecimiento</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">00</span>
                                    <input
                                        class="form-control"
                                        type="number" name="codigo_sucursal" id="codigo_sucursal"
                                        value="<?php echo $data['establecimiento']['codigo_sucursal']?>"
                                        placeholder="101"
                                    />
                                </div>
                            </div>
                            <div class="mb-3 col-md-5">
                                <label for="nombre_sucursal" class="form-label">Nombre del Establecimiento</label>
                                <input
                                    class="form-control"
                                    type="text"
                                    id="nombre_sucursal"
                                    name="nombre_sucursal"
                                    value="<?php echo $data['establecimiento']['nombre_sucursal']?>"
                                    placeholder="Nombre de la Sucursal Ej. Edificio 2"

                                />
                            </div>
                            <div class="mb-3 col-md-4">
                                <label for="nombre_comercial_sucursal" class="form-label">Nombre Comercial del Establecimiento</label>
                                <input
                                    class="form-control"
                                    type="text"
                                    id="nombre_comercial_sucursal"
                                    name="nombre_comercial_sucursal"
                                    value="<?php echo $data['establecimiento']['nombre_comercial_sucursal']?>"
                                    placeholder="Nombre de la Sucursal Ej. Edificio 2"

                                />
                            </div>
                            <div class="mb-3 col-md-12">
                                <label for="direccion_sucursal" class="form-label">Dirección Establecimiento</label>
                                <input
                                    class="form-control"
                                    type="text"
                                    id="direccion_sucursal"
                                    name="direccion_sucursal"
                                    value="<?php echo $data['establecimiento']['direccion_sucursal']?>"
                                    placeholder="Av. Siempre viva y Esquina"
                                />
                            </div>



                            <div class="mb-3 col-md-6">
                                <div class="col-md">
                                    <label class="form-check-label" for="lleva_contabilidad">¿El Establecimiento es Matriz?</label>
                                    <div class="form-check form-check-inline mt-3">
                                        <label class="form-check-label" for="is_matriz"></label>
                                        <input class="form-check-input" type="checkbox" id="is_matriz" name="is_matriz"
                                            <?php if($data['establecimiento']['is_matriz'] == 1){?>
                                                 checked <?php }else{?>
                                                disabled <?php }?>
                                        >


                                    </div>

                                </div>

                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="submit" id="btn-enviar" class="btn btn-primary me-2">Actualizar Datos del Establecimiento</button>
                            <a  href="<?php echo base_url()?>informacion/empresas" class="btn btn-outline-secondary">Cancelar</a>
                        </div>
                    </form>
                </div>
                <!-- /Account -->
            </div>

        </div>
    </div>
</div>



<?php
scripts($data);
?>
<script src="<?php echo media()?>/js/web/establecimientosEmpresa.js"></script>
<?php
fin();
?>



