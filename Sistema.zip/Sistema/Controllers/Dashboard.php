<?php
require_once("Models/NavModel.php");
require_once("Models/InformaciongeneralModel.php");
class Dashboard extends Controllers
{
    public function __construct()
    {
        session_start();
        if(empty($_SESSION['login']))
        {
            header('Location: '.base_url());
        }
        parent::__construct();
    }
    public function dashboard(){
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();
        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['tag_page'] = "Dashboard";
        $data['page_title'] = "Dashboard";
        $data['page_name'] = "dashoard";
        $this->views->getView($this,"dashboard",$data);
    }

    public function cambioEmpresa($id){
        $empresa = new InformaciongeneralModel();

        try {
            $respuesta = $empresa->getEmpresa($id);
            $idEmpresa = $respuesta['id_empresa'];
            $arrResponse = array('status' => true, 'msg' => 'OK',
                'title' => 'Correcto', 'icon' => 'success', 'data' => $respuesta);

            $_SESSION['id_empresa']['id_empresa'] = $idEmpresa;


        } catch (Exception $e) {
            $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' => 'error');
        }
        echo json_encode($arrResponse, JSON_UNESCAPED_UNICODE);
    }
}