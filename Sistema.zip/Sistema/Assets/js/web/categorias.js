var tableCategorias;
function requestAll(){
    return  request = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
}
document.addEventListener('DOMContentLoaded', function(){
    tableCategorias = $('#tableCategorias').DataTable( {
        "aProcessing":true,
        "aServerSide":true,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
        },
        "ajax":{
            "url": " "+base_url+"categorias/getDataTable",
            "dataSrc":""
        },
        "columns":[
            {"data":"id_categoria"},
            {"data":"nombre_categoria"},
            {"data":"descripcion_categoria"},
            {"data":"estado"},
            {"data":"options"}
        ],
        'dom': 'Bfrtip',

        'buttons': [
            {
                "extend": "copyHtml5",
                "text": "<i class='far fa-copy'></i> Copiar",
                "titleAttr":"Copiar",
                "className": "btn btn-secondary"
            },{
                "extend": "excelHtml5",
                "text": "<i class='fas fa-file-excel'></i> Excel",
                "titleAttr":"Exportar a Excel",
                "className": "btn btn-success"
            },{
                "extend": "pdfHtml5",
                "text": "<i class='fas fa-file-pdf'></i> PDF",
                "titleAttr":"Exportar a PDF",
                "messageTop": "Reporte General de Categorias",
                "className": "btn btn-danger",
                "exportOptions": {
                    "columns": [ 1,2,3,4,5]
                }
            }
        ],
        "resonsieve":"true",
        "bDestroy": true,
        "autoFill": true,
        "iDisplayLength": 10,
        "order":[[0,"acs"]]
    });

}, false);


function crearCategoria(){
    $('#modalCrearCategoria').modal('show');
}
function editCategoria(id){
    console.log(id);
    $.ajax({
        type: 'get',
        url: base_url+'categorias/show/'+id,
        cache: false,
        contentType: false,
        processData: false,
        beforeSend: function () {
        },
        complete: function (data) {
        },
        success: function (data) {

            var objData = JSON.parse(data);
            var datos = objData.data;
            console.log(datos);
            $('#nombreCategoria').val(datos.nombre_categoria);
            $('#descripcion').val(datos.descripcion_categoria);
            $('#idCategoria').val(datos.id_categoria);
            $('#btn-enviar').text("Actualizar Categoria");
            $('#formCrearCategoria').prop('action', base_url+'categorias/update/'+datos.id_categoria);
            $('#modalCrearCategoria').modal('show');
        },
        error: function (data) {
            Swal.fire({
                title: 'Error',
                text: 'Problemas al tratar de enviar el formulario',
                icon: 'error',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
                target: document.getElementById('modalCrearCategoria'),
            }).then((result) => {
                location.reload();
            })
        }
    });

}
$(document).ready(function () {
    $("#formCrearCategoria").bind("submit", function (e) {
        // Capturamnos el boton de envío
        if(validar() == true){

            var formData = new FormData(this);
            e.preventDefault();
            console.log(formData);
            $.ajax({
                type: $(this).attr("method"),
                url: $(this).attr("action"),
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function () {
                },
                complete: function (data) {
                },
                success: function (data) {

                    var objData = JSON.parse(data);
                    var respuesta = objData.msg;
                    var title = objData.title;
                    var icon = objData.icon;
                    console.log(objData);
                    Swal.fire({
                        title: title,
                        text: respuesta,
                        icon: icon,
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                        target: document.getElementById('modalCrearCategoria'),
                    }).then((result) => {
                        if (title != "Error") {
                            window.location.href = '../../facturero/categorias'
                        } else {
                            location.reload();
                        }
                    })
                },
                error: function (data) {
                    Swal.fire({
                        title: 'Error',
                        text: 'Problemas al tratar de enviar el formulario',
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                        target: document.getElementById('modalCrearCategoria'),
                    }).then((result) => {
                        location.reload();
                    })
                }
            });
            return false;
        }else{
            Swal.fire({
                title: 'Error',
                text: 'Debe de Rellenar los campos requeridos.',
                icon: 'error',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
                target: document.getElementById('modalCrearCategoria'),
            }).then((result) => {

            })
            e.preventDefault();
        }
    });
});

function eliminar(id){

    Swal.fire({
        title: 'Esta Seguro que desea Eliminar la Categoria?',
        text: "Recuerde que esta Operación es Irreversible. ",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si Eliminar Categoria'
    }).then((result) => {
        if (result.isConfirmed) {
            var ajaxUrl = base_url+'categorias/delete/'+id;

            $.ajax({
                type: 'get',
                url: ajaxUrl,
                data: id,
                cache: false,
                contentType: false,
                processData: false,
                success: function (data) {
                    /*
                    * Se ejecuta cuando termina la petición y esta ha sido
                    * correcta
                    * */
                    var objData = JSON.parse(data);
                    var respuesta = objData.msg;
                    var title = objData.title;
                    var icon = objData.icon;
                    console.log(objData);
                    Swal.fire({
                        title: title,
                        text: respuesta,
                        icon: icon,
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        if (title != "Error") {
                            window.location.href = '../../facturero/categorias';
                        } else {
                            location.reload();
                        }

                    })
                },
                error: function (data) {
                    /*
                    * Se ejecuta si la peticón ha sido erronea
                    * */
                    Swal.fire({
                        title: 'Error',
                        text: 'Problemas al tratar de eliminar la Categoria.',
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        location.reload();
                    })
                }
            });

        }
    })
}

function validar() {
    let nombre_categoria = $('#nombreCategoria').val();
    let descripcion_categoria = $('#descripcion').val();

    if(nombre_categoria != ""){

        if( descripcion_categoria != "" ){
            return true;
        }else{
            return false;
        }
    }else {
        return false;
    }
}
