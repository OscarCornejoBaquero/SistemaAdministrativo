<?php
require_once ("Objetos/Login/User.php");
class ExLogin extends Controllers
{
    private User $objUsuario;
    public $mensaje;
    public function __construct()
    {
        parent::__construct();
    }

    public function usuarioExistente($request_user){
        if($request_user == 'exist'){
            throw new Exception('¡Atención! el Usuario ingresado ya existe, intente con otro.');
        }
        return true;
    }
    public function errorLogin($request){
        if($request == 'loginInvalido'){
            throw new Exception('¡Atención! el Usuario y Password no coinciden.');
        }
        return true;
    }
    public function validarMail($request){
        if(!$request){
            throw new Exception('¡Atención! Error al Enviar el Correo.');
        }
    }
}