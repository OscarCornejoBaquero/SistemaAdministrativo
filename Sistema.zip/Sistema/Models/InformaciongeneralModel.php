<?php

class InformaciongeneralModel extends Mysql
{
    public function __construct()
    {
        parent::__construct();

    }
    public function getProvincias(){
        $sql = "select cod_provincia, nombre_provincia from tb_provincias where estado = '1' ";
        return $this->select_all($sql);
    }
    public function getCiudades($idProvincia){
        $sql = "call getCiudades('{$idProvincia}')";
        return $this->select_all($sql);
    }
    public function getEmpresa($id){
        $sql = "call validarEmpresaExiste('{$id}')";
        return $this->select($sql);
    }
}