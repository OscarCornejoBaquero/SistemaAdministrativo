<div class="modal fade" id="modalProveedor" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">


                <h5 class="modal-title centrado" id="titleProveedor">Información del Proveedor</h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="id_proveedor">
                <div class="row">
                    <div class="col-12">
                        <table class="table table-bordered"  >
                            <tbody >
                            <tr>
                                <td class="formatoTableModal">Razón Social:</td>
                                <td id="razon_social" class="formatoTableModal"></td>
                            </tr>
                            <tr>
                                <td class="formatoTableModal">Ruc Proveedor:</td>
                                <td id="ruc_social" class="formatoTableModal"></td>
                            </tr>
                            <tr>
                                <td class="formatoTableModal">Correo Proveedor:</td>
                                <td id="correo_proveedor" class="formatoTableModal"></td>
                            </tr>
                            <tr>
                                <td class="formatoTableModal">Teléfono Principal:</td>
                                <td id="telefono1"class="formatoTableModal"></td>
                            </tr>
                            <tr>
                                <td sclass="formatoTableModal">Teléfono Secundario:</td>
                                <td id="telefono2"class="formatoTableModal"></td>
                            </tr>
                            <tr>
                                <td class="formatoTableModal">Dirección Proveedor:</td>
                                <td id="direccion"class="formatoTableModal"></td>
                            </tr>
                            <tr>
                                <td sclass="formatoTableModal">Ciudad:</td>
                                <td id="nombre_ciudad"class="formatoTableModal"></td>
                            </tr>
                            <tr>
                                <td sclass="formatoTableModal">Provincia:</td>
                                <td id="nombre_provincia"class="formatoTableModal"></td>
                            </tr>

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cerrar
                </button>
                <button type="button" class="btn btn-primary" onclick="editarProveedor();" >Editar Establecimiento</button>
            </div>
        </div>
    </div>
</div>