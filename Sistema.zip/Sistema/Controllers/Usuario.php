<?php
require_once("Models/NavModel.php");
require_once ("Excepciones/ExUsuarios.php");
require_once ("Objetos/Login/User.php");
class Usuario extends Controllers
{
    private User $objUsuario;
    private ExUsuarios $validaciones ;
    public function __construct()
    {
        session_start();
        if(empty($_SESSION['login']))
        {
            header('Location: '.base_url());
        }
        parent::__construct();
        $this->validaciones = new ExUsuarios();
    }
    public function perfilUsuario(){
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();
        $data['genero'] = $this->model->getGeneros();
        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['tag_page'] = "Perfil de Usuario";
        $data['page_title'] = "Perfil de Usuario";
        $data['page_name'] = "Perfil de Usuario";
        $this->views->getView($this,"perfilUsuario",$data);
    }
    public function update(){
        if($_POST){
            try {
                $this->objUsuario = new User();
                $this->objUsuario->setIdUser($_POST['idProfile']);
                $this->objUsuario->setNombres($_POST['firstName']);
                $this->objUsuario->setApellidos($_POST['lastName']);
                $this->objUsuario->setGenero($_POST['genero']);
                $this->objUsuario->setIdentificacion($_POST['identificacion']);
                $this->objUsuario->setEmail($_POST['email']);
                $this->objUsuario->setEmail2($_POST['email_secundario']);
                $this->objUsuario->setDireccion($_POST['direccion']);
                $this->objUsuario->setConvencional($_POST['telefono_convencional']);
                $this->objUsuario->setCelular($_POST['telefono_celular']);
                $newName="";
                $archivo = $_FILES['upload']['name'];
                if (isset($archivo) && $archivo != "") {
                    $array = explode('.', $_FILES['upload']['name']);
                    $tipo = end($array);
                    $newName = "profile" . $this->objUsuario->getIdentificacion() .'.'. $tipo;
                    if(move_uploaded_file($_FILES["upload"]["tmp_name"], $_SERVER['DOCUMENT_ROOT']."/facturero/Assets/img/img_profile/" . $newName)){
                        $this->objUsuario->setUrlFoto($newName);
                    }
                }
                $this->objUsuario->setUrlFoto("$newName");
                $respuesta = $this->model->updateUser($this->objUsuario);
                $this->validaciones->usuarioExistente($respuesta);
                //$prueba = $this->model->getInforUser($_SESSION['user_data']['usuario']);
                $_SESSION['user_data']= $this->model->getInforUser($_SESSION['user_data']['usuario']);
                $arrResponse = array('status' => true, 'msg' => 'Actualizado Correctamente', 'title' => 'Correcto','icon'=>'success');
            } catch (Exception $e) {
                $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' =>'error');
            }
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
        }
        die();
    }

}