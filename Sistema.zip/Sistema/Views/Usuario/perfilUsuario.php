<?php
headers($data);
?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Usuarios /</span> <?php echo $data['tag_page']?></h4>

    <div class="row">
        <div class="col-md-12">
            <ul class="nav nav-pills flex-column flex-md-row mb-3">
                <li class="nav-item">
                    <a class="nav-link active" href="javascript:void(0);"><i class="bx bx-user me-1"></i> Datos Personales</a>
                </li>
                <!--
                <li class="nav-item">
                    <a class="nav-link" href="pages-account-settings-notifications.html"
                    ><i class="bx bx-bell me-1"></i> Notifications</a
                    >
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pages-account-settings-connections.html"
                    ><i class="bx bx-link-alt me-1"></i> Connections</a
                    >
                </li>
                -->
            </ul>
            <div class="card mb-4">
                <h5 class="card-header">Profile Details</h5>

                <div class="card-body">
                    <form id="formActualizarPerfil" method="POST" action="<?php echo base_url()?>usuario/update" enctype="multipart/formdata" >
                        <div class="card-body">
                            <input type="hidden" name="idProfile" value="<?php echo $_SESSION['id_user'] ?>">
                            <div class="d-flex align-items-start align-items-sm-center gap-4">
                                <?php if($_SESSION['user_data']['url_profile'] == null){
                                    ?>
                                    <img
                                        src="<?php echo media()?>/img/avatar.png"
                                        alt="user-avatar"
                                        class="d-block rounded circlarImagen"
                                        height="200"
                                        width="200"
                                        id="uploadedAvatar"

                                    />
                                    <?php
                                } else { ?>
                                    <img
                                        src="<?php echo media()?>/img/img_profile/<?php echo $_SESSION['user_data']['url_profile'] ?>"
                                        alt="user-avatar"
                                        class="d-block rounded circlarImagen"
                                        height="100"
                                        width="100"
                                        id="uploadedAvatar"

                                    />
                                    <?php
                                }?>

                                <div class="button-wrapper">
                                    <label for="upload" class="btn btn-primary me-2 mb-4" tabindex="0">
                                        <span class="d-none d-sm-block">Subir foto de Perfil</span>
                                        <i class="bx bx-upload d-block d-sm-none"></i>
                                        <input
                                            type="file"
                                            id="upload"
                                            name="upload"
                                            hidden
                                            class="account-file-input"
                                            accept="image/png, image/jpeg"
                                        />
                                    </label>
                                    <button type="reset" class="btn btn-outline-secondary account-image-reset mb-4">
                                        <i class="bx bx-reset d-block d-sm-none"></i>
                                        <span class="d-none d-sm-block">Limpiar Datos </span>
                                    </button>

                                    <p class="text-muted mb-0">Solo se aceptan Imágenes JPG, GIF or PNG. Tamaño máximo de 1mb</p>
                                </div>
                            </div>
                        </div>
                        <hr class="my-0" />
                        <div class="row">
                            <div class="mb-3 col-md-6">
                                <label for="firstName" class="form-label">Nombres</label>
                                <input
                                    class="form-control"
                                    type="text"
                                    id="firstName"
                                    name="firstName"
                                    value="<?php echo $_SESSION['user_data']['nombres'] ?>"
                                    autofocus
                                />
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="lastName" class="form-label">Apellidos</label>
                                <input
                                    class="form-control"
                                    type="text" name="lastName" id="lastName"
                                    value="<?php echo $_SESSION['user_data']['apellidos']?>" />
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="genero" class="form-label">Genero</label>
                                <select id="genero" name="genero" class="select2 form-select">
                                    <option value="0">Seleccione un Genero</option>
                                    <?php
                                    foreach ($data['genero'] as $genero){
                                        ?>
                                    <option value="<?php echo $genero['id_genero']?>" <?php
                                    if($genero['id_genero'] == $_SESSION['user_data']['id_genero']){
                                        ?>selected

                                    <?php }
                                    ?>>

                                        <?php echo $genero['nombre']?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="identificacion" class="form-label">Identificación</label>
                                <input
                                        class="form-control"
                                        type="text" name="identificacion" id="identificacion"
                                        value="<?php echo $_SESSION['user_data']['identificacion']?>"
                                        placeholder="0999999999"/>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="email" class="form-label">E-mail Principal</label>
                                <input
                                    class="form-control"
                                    type="text"
                                    id="email"
                                    name="email"
                                    value="<?php echo $_SESSION['user_data']['correo_principal']?>"
                                    placeholder="john.doe@example.com"
                                />
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="email_secundario" class="form-label">E-mail Secundario</label>
                                <input
                                        class="form-control"
                                        type="text"
                                        id="email_secundario"
                                        name="email_secundario"
                                        value="<?php echo $_SESSION['user_data']['correo_secundario']?>"
                                        placeholder="john.doe@example.com"
                                />
                            </div>

                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="telefono_celular">Teléfono Celular</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">ECU (+593)</span>
                                    <input
                                        type="number"
                                        id="telefono_celular"
                                        name="telefono_celular"
                                        class="form-control"
                                        value="<?php echo $_SESSION['user_data']['telefono_celular']?>"
                                        placeholder="981814691"
                                    />
                                </div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="telefono_convencional">Teléfono Convencional</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text">ECU (+593)</span>
                                    <input
                                            type="number"
                                            id="telefono_convencional"
                                            name="telefono_convencional"
                                            class="form-control"
                                            value="<?php echo $_SESSION['user_data']['telefono_convencional']?>"
                                            placeholder="42259374"
                                    />
                                </div>
                            </div>
                            <?php echo $_SESSION['user_data']['usuario']?>
                            <div class="mb-3 col-md-12">
                                <label for="direccion" class="form-label">Dirección</label>
                                <input type="text" class="form-control" id="direccion"
                                       value="<?php echo $_SESSION['user_data']['direccion']?>"
                                       name="direccion" placeholder="Dirección" />
                            </div>

                        </div>
                        <div class="mt-2">
                            <button type="submit" id="btn-enviar" class="btn btn-primary me-2">Guardar Cambios</button>
                            <button type="reset" class="btn btn-outline-secondary">Cancelar</button>
                        </div>
                    </form>
                </div>
                <!-- /Account -->
            </div>
            <div class="card">
                <h5 class="card-header">Desactivar Cuenta</h5>
                <div class="card-body">
                    <div class="mb-3 col-12 mb-0">
                        <div class="alert alert-warning">
                            <h6 class="alert-heading fw-bold mb-1">¿Esta seguro que desea desactivar la Cuenta?</h6>
                            <p class="mb-0">Para volver a activar su cuenta debe de registrarse nuevamente y perderá todos los
                            comprobantes ya enviador y recibidos </p>
                        </div>
                    </div>
                    <form id="formAccountDeactivation" onsubmit="return false">
                        <div class="form-check mb-3">
                            <input
                                class="form-check-input"
                                type="checkbox"
                                name="accountActivation"
                                id="accountActivation"
                            />
                            <label class="form-check-label" for="accountActivation"
                            >Yo, Confirmo que deseo desactivar mi cuenta. </label
                            >
                        </div>
                        <button type="submit" id="desactivarCuenta" class="btn btn-danger deactivate-account" disabled>Desactive Cuenta</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
scripts($data);
fin();
?>
