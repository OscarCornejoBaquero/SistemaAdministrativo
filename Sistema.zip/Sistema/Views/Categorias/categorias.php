<?php
headers($data);
getModal('crearCategoria',$data);
?>

<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"> Productos /</span> <?php echo $data['tag_page']?></h4>

    <!-- Basic Bootstrap Table -->
    <div class="card">
        <div class="row">
            <div class="col-9 card-header">
                <h5 class="card-header" ><?php echo $data['tag_page'] ?></h5>
            </div>

            <div class="col-sm-12 col-lg-3  card-header">
                <a type="button" class="btn btn-outline-warning " href="#" onclick="crearCategoria();" style="color: black" title="Agregar Categoria">
                    <span class="tf-icons bx bx-plus" ></span>&nbsp; Categorias
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive ">
                <table class="table table-striped" id="tableCategorias">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>NOMBRE DE LA CATEGORIA</th>
                        <th>DESCRIPCION</th>
                        <th>ESTADO</th>
                        <th>OPCIONES</th>
                    </tr>
                    </thead>
                    <tbody >

                    </tbody>
                </table>
            </div>
        </div>
    </div>


</div>


<?php
scripts($data);
?>
<script src="<?php echo media()?>/js/web/categorias.js"></script>
<?php
fin();
?>
