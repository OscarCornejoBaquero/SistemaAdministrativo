<?php

class Sucursal
{
    private int $idEstablecimiento;
    private int $idEmpresa;
    private int $isMatriz;
    private string $codigoSucursal;
    private string $nombreSucursal;
    private string $direccionSucursal;
    private string $nombreComercial;
    private string $logoSucursal;
    private int $estado;

    public function __construct()
    {
    }

    /**
     * @return int
     */
    public function getIdEstablecimiento(): int
    {
        return $this->idEstablecimiento;
    }

    /**
     * @param int $idEstablecimiento
     */
    public function setIdEstablecimiento(int $idEstablecimiento): void
    {
        $this->idEstablecimiento = $idEstablecimiento;
    }

    /**
     * @return int
     */
    public function getIdEmpresa(): int
    {
        return $this->idEmpresa;
    }

    /**
     * @param int $idEmpresa
     */
    public function setIdEmpresa(int $idEmpresa): void
    {
        $this->idEmpresa = $idEmpresa;
    }

    /**
     * @return int
     */
    public function getIsMatriz(): int
    {
        return $this->isMatriz;
    }

    /**
     * @param int $isMatriz
     */
    public function setIsMatriz(int $isMatriz): void
    {
        $this->isMatriz = $isMatriz;
    }

    /**
     * @return string
     */
    public function getCodigoSucursal(): string
    {
        return $this->codigoSucursal;
    }

    /**
     * @param string $codigoSucursal
     */
    public function setCodigoSucursal(string $codigoSucursal): void
    {
        $this->codigoSucursal = $codigoSucursal;
    }

    /**
     * @return string
     */
    public function getNombreSucursal(): string
    {
        return $this->nombreSucursal;
    }

    /**
     * @param string $nombreSucursal
     */
    public function setNombreSucursal(string $nombreSucursal): void
    {
        $this->nombreSucursal = $nombreSucursal;
    }

    /**
     * @return string
     */
    public function getDireccionSucursal(): string
    {
        return $this->direccionSucursal;
    }

    /**
     * @param string $direccionSucursal
     */
    public function setDireccionSucursal(string $direccionSucursal): void
    {
        $this->direccionSucursal = $direccionSucursal;
    }

    /**
     * @return string
     */
    public function getNombreComercial(): string
    {
        return $this->nombreComercial;
    }

    /**
     * @param string $nombreComercial
     */
    public function setNombreComercial(string $nombreComercial): void
    {
        $this->nombreComercial = $nombreComercial;
    }

    /**
     * @return string
     */
    public function getLogoSucursal(): string
    {
        return $this->logoSucursal;
    }

    /**
     * @param string $logoSucursal
     */
    public function setLogoSucursal(string $logoSucursal): void
    {
        $this->logoSucursal = $logoSucursal;
    }

    /**
     * @return int
     */
    public function getEstado(): int
    {
        return $this->estado;
    }

    /**
     * @param int $estado
     */
    public function setEstado(int $estado): void
    {
        $this->estado = $estado;
    }

}