<?php
require_once("Models/NavModel.php");
require_once ("Excepciones/ExEmpresa.php");
require_once ("Objetos/Empresa/Empresa.php");
class InformacionModel extends Mysql
{
    private Empresa $objEmpresa;
    public function __construct()
    {
        parent::__construct();

    }
    public function selectAllEmpresas($id_user){
        $sql = "call todas_empresas('{$id_user}') ";
        return $this->select_all($sql);
    }
    public function getInformacionEmpresa($id_user){
        $sql = "call inforEmpresa('{$id_user}') ";
        //$sql = "select * from tb_empresa_user ";
        return $this->select($sql);
    }
    public function getTipoContribuyente(){
        $sql = "select * from tb_tipo_contribuyente";
        return $this->select_all($sql);
    }
    public function updateEmpresa($objEmpresa){
        $this->objEmpresa = $objEmpresa;
        $sql = "call validarEmpresaExiste('{$this->objEmpresa->getIdEmpresa()}') ";
        $request = $this->select($sql);
        if($this->objEmpresa->getLogo() == null || $this->objEmpresa->getLogo() == ""){
            $this->objEmpresa->setLogo($request['logo_empresa']);
        }
        if($this->objEmpresa->getFirma() == null || $this->objEmpresa->getFirma() == ""){
            $this->objEmpresa->setFirma($request['url_archivo_firma']);
        }
        if(empty($request)){
            $return = "NO Existe";
        }else{
            $sql = "call updateEmpresa(?, ?, ?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $arrData = array($this->objEmpresa->getIdEmpresa(), $this->objEmpresa->getRuc(),
                $this->objEmpresa->getRazonSocial(),$this->objEmpresa->getNombreComercial(),
                $this->objEmpresa->getCorreo(), $this->objEmpresa->getTelefono(),
                $this->objEmpresa->getDireccion(),$this->objEmpresa->getLogo(),
                $this->objEmpresa->getTipoContribuyente(),$this->objEmpresa->getAgenteRetencion(),
                $this->objEmpresa->getContribuyenteEspecial(),$this->objEmpresa->getCodigoArtesano(),
                $this->objEmpresa->getNombreRecibos(),$this->objEmpresa->getFirma(),
                $this->objEmpresa->getPassFirma(),$this->objEmpresa->getLlevaContabilidad(),
                $this->objEmpresa->getEstado()
                );
            $request_update = $this->update($sql,$arrData);
            $return = $request_update;
        }
        return  $return;
    }
    public function eliminarEmpresa($id){
        $sql = "call inforEmpresa('{$id}') ";
        $consulta = $this->select($sql);
        $nombre_fichero = $_SERVER['DOCUMENT_ROOT']."/facturero/Assets/img/empresas/logos/" .$consulta['logo_empresa'];
        if (file_exists($nombre_fichero)) {
            unlink($nombre_fichero);
        }
        $sql = "call eliminarEmpresa('{$id}')";
        return $this->delete($sql);
    }
    public function storeEmpresa($objEmpresa){
        $this->objEmpresa = $objEmpresa;
        $sql = "call validarEmpresaExisteRUC('{$this->objEmpresa->getRuc()}') ";
        $request = $this->select($sql);
        if(empty($request)){
            $sql = "call storeEmpresa(?,?, ?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $arrData = array( $this->objEmpresa->getIdUser(), $this->objEmpresa->getRuc(),
                $this->objEmpresa->getRazonSocial(),$this->objEmpresa->getNombreComercial(),
                $this->objEmpresa->getCorreo(), $this->objEmpresa->getTelefono(),
                $this->objEmpresa->getDireccion(),$this->objEmpresa->getLogo(),
                $this->objEmpresa->getTipoContribuyente(),$this->objEmpresa->getAgenteRetencion(),
                $this->objEmpresa->getContribuyenteEspecial(),$this->objEmpresa->getCodigoArtesano(),
                $this->objEmpresa->getNombreRecibos(),$this->objEmpresa->getFirma(),
                $this->objEmpresa->getPassFirma(),$this->objEmpresa->getLlevaContabilidad(),
                $this->objEmpresa->getEstado()
            );
            $request_store = $this->insert($sql,$arrData);
            $return = $request_store;
        }else{
            $return = "Empresa Existe";

        }
        return  $return;
    }
}