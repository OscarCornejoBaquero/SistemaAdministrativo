<?php
headers($data);
getModal('informacionProvedor',$data);
?>

<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"> Agentes Externos /</span> <?php echo $data['tag_page']?></h4>

    <!-- Basic Bootstrap Table -->
    <div class="card">
        <div class="row">
            <div class="col-9 card-header">
                <h5 class="card-header" ><?php echo $data['tag_page'] ?></h5>
            </div>

            <div class="col-sm-12 col-lg-3  card-header">
                <a type="button" class="btn btn-outline-warning " href="<?php echo base_url()?>proveedores/create" style="color: black" title="Agregar Proveedor">
                    <span class="tf-icons bx bx-plus" ></span>&nbsp; Proveedor
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive ">
                <table class="table table-striped" id="tableProveedores">
                    <thead>
                    <tr>
                        <th>VER</th>
                        <th>RAZÓN SOCIAL</th>
                        <th>RUC</th>
                        <th>TELÉFONO</th>
                        <th>CORREO</th>
                        <th>ESTADO</th>
                        <th>OPCIONES</th>
                    </tr>
                    </thead>
                    <tbody >

                    </tbody>
                </table>
            </div>
        </div>
    </div>


</div>


<?php
scripts($data);
?>
<script src="<?php echo media()?>/js/web/proveedores.js"></script>
<?php
fin();
?>
