<?php
require_once("Models/NavModel.php");
require_once ("Excepciones/ExProductos.php");
require_once("Models/Crud.php");
class Categorias extends Controllers implements Crud
{
    private ExProductos $validaciones ;
    public function __construct()
    {
        session_start();
        if (empty($_SESSION['login'])) {
            header('Location: ' . base_url());
        }
        parent::__construct();
        $this->validaciones = new ExProductos();
    }
    public function categorias(){
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();
        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['categorias'] =  $this->model->getCategoriaCreate();
        $data['tag_page'] = "Categorias";
        $data['page_title'] = "Categoria";
        $data['page_name'] = "Categoria de los Productos";
        $this->views->getView($this, "categorias", $data);
    }
    public function getDataTable()
    {
        // TODO: Implement getDataTable() method.
        $arrData = $this->model->getDataTable();
        for ($i = 0; $i < sizeof($arrData); $i++) {
            $datos = $arrData[$i]['id_categoria'];
            if ($arrData[$i]['estado'] == 1) {
                $arrData[$i]['estado'] = '<span class="badge badge-success" style="background: green">Activo</span>';
            } else {
                $arrData[$i]['estado'] = '<span class="badge badge-danger" style="background: red">Inactivo</span>';
            }
            $arrData[$i]['options'] = '
            <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu">
                                
                                <a class="dropdown-item" href="#" onclick="editCategoria('.$datos.');"
                                ><i class="bx bx-edit-alt me-1"></i> Editar</a
                                >
                                <a class="dropdown-item " href="#" onclick="eliminar('.$datos.');"
                                ><i class="bx bx-trash me-1"></i> Eliminar</a
                                >
                            </div>
                        </div>
            ';
        }
        echo json_encode($arrData, JSON_UNESCAPED_UNICODE);
        die();
    }

    public function show($id)
    {
        // TODO: Implement show() method.
        try {
            $respuesta = $this->model->show($id);
            $arrResponse = array('status' => true, 'msg' => 'OK',
                'title' => 'Correcto', 'icon' => 'success', 'data' => $respuesta);

        } catch (Exception $e) {
            $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' => 'error');
        }
        echo json_encode($arrResponse, JSON_UNESCAPED_UNICODE);
    }

    public function create()
    {
        // TODO: Implement create() method.

    }

    public function store()
    {
        // TODO: Implement store() method.
        if($_POST){
            try {
                $nombre = $_POST['nombreCategoria'];
                $detalle = $_POST['descripcion'];
                $respuesta = $this->model->store($nombre, $detalle);
                $this->validaciones->storeCategoria($respuesta);

                $arrResponse = array('status' => true, 'msg' => 'Categoria Creada Correctamente', 'title' => 'Correcto','icon'=>'success');
            } catch (Exception $e) {
                $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' =>'error');
            }
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
        }
        die();
    }

    public function edit($id)
    {
        // TODO: Implement edit() method.

    }

    public function update()
    {
        // TODO: Implement update() method.
        if($_POST){
            try {
                $nombre = $_POST['nombreCategoria'];
                $detalle = $_POST['descripcion'];
                $id = $_POST['idCategoria'];
                $respuesta = $this->model->updateCategoria($nombre, $detalle,$id);

                $arrResponse = array('status' => true, 'msg' => 'Categoria Actualizada Correctamente', 'title' => 'Correcto','icon'=>'success');
            } catch (Exception $e) {
                $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' =>'error');
            }
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
        }
        die();
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
        try {
            $respuesta = $this->model->deleteCategoria($id);

            $arrResponse = array('status' => true, 'msg' => 'Categoria Eliminada de Forma Correcta',
                'title' => 'Correcto', 'icon' => 'success', 'data' => $respuesta);

        } catch (Exception $e) {
            $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' => 'error');
        }
        echo json_encode($arrResponse, JSON_UNESCAPED_UNICODE);
    }
}