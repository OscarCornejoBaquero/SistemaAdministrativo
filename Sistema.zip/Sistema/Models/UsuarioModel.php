<?php
require_once ("Objetos/Login/User.php");
class UsuarioModel extends Mysql
{
    private User $objUsuario;
    public function __construct()
    {
        parent::__construct();
    }

    public function getGeneros(){
        $sql = "select * from tb_genero where estado != 0";
        return $this->select_all($sql);
    }
   public function updateUser(User $objUser){
       $this->objUsuario = $objUser;
       $sql = "call validarUsuarioExiste('{$this->objUsuario->getIdUser()}') ";
       $request = $this->select($sql);
       if(empty($request)){
           $return = "NO Existe";
       }else{
           $sql = "call updateUser(?, ?, ?, ?,?,?,?,?,?,?,?)";
           $arrData = array($this->objUsuario->getNombres(), $this->objUsuario->getApellidos(),
               $this->objUsuario->getGenero(),$this->objUsuario->getIdentificacion(),
               $this->objUsuario->getEmail(), $this->objUsuario->getEmail2(),
               $this->objUsuario->getDireccion(),$this->objUsuario->getConvencional(),
               $this->objUsuario->getCelular(),$this->objUsuario->getUrlFoto(),
               $this->objUsuario->getIdUser());
           $request_update = $this->update($sql,$arrData);
           $return = $request_update;
       }
       return  $return;
   }
   public function getInforUser(string $user){
       $sql = "call inforUser('{$user}') ";
       $request = $this->select($sql);
       return $request;
   }
}