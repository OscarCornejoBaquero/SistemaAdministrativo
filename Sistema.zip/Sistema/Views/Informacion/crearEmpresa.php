<?php
headers($data);

?>


<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Datos Tributarios /</span> <?php echo $data['tag_page']?></h4>

    <div class="row">
        <div class="col-md-12">
            <ul class="nav nav-pills flex-column flex-md-row mb-3">
                <li class="nav-item">
                    <a class="nav-link active" href="javascript:void(0);"><i class="bx bx-user me-1"></i> Información de la Empresa</a>
                </li>
            </ul>
            <div class="card mb-4">
                <div class="card-body">
                    <form id="formCrearEmpresa" method="POST" action="<?php echo base_url()?>informacion/storeEmpresa" enctype="multipart/formdata" >
                        <div class="card-body">
                            <input type="hidden" name="idUser" id="idUser" value="<?php $_SESSION['id_user'] ?>">
                            <div class="d-flex align-items-start align-items-sm-center gap-4">

                                    <img
                                        src="<?php echo media()?>/img/empresas/logos/default.jpg"
                                        alt="user-avatar"
                                        class="d-block rounded circlarImagen"
                                        height="200"
                                        width="200"
                                        id="uploadLogo"

                                    />
                                <div class="button-wrapper">
                                    <label for="upload" class="btn btn-primary me-2 mb-4" tabindex="0">
                                        <span class="d-none d-sm-block">Agregar Logo</span>
                                        <i class="bx bx-upload d-block d-sm-none"></i>
                                        <input
                                            type="file"
                                            id="upload"
                                            name="upload"
                                            hidden
                                            class="account-file-input"
                                            accept="image/png, image/jpeg"
                                        />
                                    </label>
                                    <button type="reset" class="btn btn-outline-secondary account-image-reset mb-4">
                                        <i class="bx bx-reset d-block d-sm-none"></i>
                                        <span class="d-none d-sm-block">Limpiar Datos </span>
                                    </button>

                                    <p class="text-muted mb-0">Solo se aceptan Imágenes JPG, GIF or PNG. Tamaño máximo de 1mb</p>
                                </div>
                            </div>
                        </div>
                        <hr class="my-0" />
                        <div class="row">
                            <div class="mb-3 col-md-6">
                                <label for="ruc_empresa" class="form-label">Ruc-Empresa</label>
                                <input
                                    class="form-control"
                                    type="text"
                                    id="ruc_empresa"
                                    name="ruc_empresa"
                                    value=""
                                    placeholder="0909090909001"
                                    autofocus
                                />
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="razon_social_empresa" class="form-label">Razón Social</label>
                                <input
                                    class="form-control"
                                    type="text" name="razon_social_empresa" id="razon_social_empresa"
                                    value="" placeholder="Razón Social (Nombre Completo)"/>

                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="nombre_comerial_empresa" class="form-label">Nombre Comercial</label>
                                <input
                                    class="form-control"
                                    type="text" name="nombre_comerial_empresa" id="nombre_comerial_empresa"
                                    value="" placeholder="Nombre Comercial (Como se llama su Negocio)" />
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="correo_empresa" class="form-label">Correo Empresarial</label>
                                <input
                                    class="form-control"
                                    type="text" name="correo_empresa" id="correo_empresa"
                                    value=""
                                    placeholder="miempresa@miempresa.com"
                                />
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="email" class="form-label">Teléfono Empresarial</label>
                                <input
                                    class="form-control"
                                    type="text"
                                    id="telefono_empresa"
                                    name="telefono_empresa"
                                    value=""
                                    placeholder="0909090909"

                                />
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="descripcion_tipo" class="form-label">Tipo de Contribuyente</label>
                                <select id="descripcion_tipo" name="descripcion_tipo" class="select2 form-select">
                                    <option value="0">Seleccione el Tipo de Contribuyente</option>
                                    <?php
                                    foreach ($data['contribuyentes'] as $contribuyentes){
                                        ?>
                                        <option value="<?php echo $contribuyentes['id_tipo_contribuyente']?>">

                                            <?php echo $contribuyentes['descripcion_tipo']?></option>
                                    <?php }?>
                                </select>

                            </div>
                            <div class="mb-3 col-md-12">
                                <label for="direccion_empresa" class="form-label">Dirección Empresa</label>
                                <input
                                    class="form-control"
                                    type="text"
                                    id="direccion_empresa"
                                    name="direccion_empresa"
                                    value=""
                                    placeholder="Av. Siempre viva y Esquina"
                                />
                            </div>


                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="agente_retencion">Agente de Retención</label>
                                <div class="input-group input-group-merge">

                                    <input
                                        type="text"
                                        id="agente_retencion"
                                        name="agente_retencion"
                                        class="form-control"
                                        value=""
                                        placeholder="Número de Retención"
                                    />
                                </div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="contribuyente_especial">Contribuyente Especial</label>
                                <div class="input-group input-group-merge">

                                    <input
                                        type="text"
                                        id="contribuyente_especial"
                                        name="contribuyente_especial"
                                        class="form-control"
                                        value=""
                                        placeholder="Número de Resolución"

                                    />
                                </div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="codigo_artesano">Código de Artesano</label>
                                <div class="input-group input-group-merge">

                                    <input
                                        type="text"
                                        id="codigo_artesano"
                                        name="codigo_artesano"
                                        class="form-control"
                                        value=""
                                        placeholder="Código de Artesano"
                                    />
                                </div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="nombre_recibos">Nombre de Recibos</label>
                                <div class="input-group input-group-merge">

                                    <input
                                        type="text"
                                        id="nombre_recibos"
                                        name="nombre_recibos"
                                        class="form-control"
                                        value=""
                                        placeholder="Nombre para mostrar en recibos"
                                    />
                                </div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="url_archivo_firma">Firma Electronica</label>
                                <div class="input-group input-group-merge">
                                    <input class="form-control" type="file" id="url_archivo_firma" name="url_archivo_firma">
                                </div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="pass_firma_electronica">Contraseña de la Firma Electronica</label>




                                <div class="input-group input-group-merge">
                                    <input type="password" id="pass_firma_electronica" class="form-control" name="pass_firma_electronica" placeholder="············" aria-describedby="password">
                                    <span class="input-group-text cursor-pointer"><i class="icon bx bx-hide" onclick="mostrarPassword()"></i></span>
                                </div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <div class="col-md">

                                    <div class="form-check form-check-inline mt-3">
                                        <input class="form-check-input" type="checkbox" id="lleva_contabilidad" name="lleva_contabilidad"

                                        >
                                        <label class="form-check-label" for="lleva_contabilidad">Obligado a llevar contabilidad</label>
                                    </div>
                                    <div class="form-check form-check-inline mt-3">
                                        <input class="form-check-input" type="checkbox" id="estado" name="estado"

                                        >
                                        <label class="form-check-label" for="estado">Empresa Activa?</label>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="submit" id="btn-enviar" class="btn btn-primary me-2">Guardar Datos de la Empresa</button>
                            <a  href="<?php echo base_url()?>informacion/empresas" class="btn btn-outline-secondary">Cancelar</a>
                        </div>
                    </form>
                </div>
                <!-- /Account -->
            </div>

        </div>
    </div>
</div>



<?php
scripts($data);
?>
<script src="<?php echo media()?>/js/web/empresas.js"></script>
<?php
fin();
?>


