<?php
require_once ("Objetos/Login/User.php");
require_once ("Excepciones/ExLogin.php");
require_once ("Controllers/EnvioCorreo.php");
require_once ("Helpers/ModelosCorreo.php");
class Registro extends Controllers
{
    private User $objUsuario;
    private ExLogin $validaciones ;
    public function __construct()
    {

        parent::__construct();
        $this->validaciones = new ExLogin();
    }
    public function registro(){
        $data['tag_page'] = "Registro de Clientes";
        $data['page_title'] = "Registro de Clientes";
        $data['page_name'] = "Registro";
        $this->views->getView($this,"registro",$data);
    }
    public function create()
    {
        if($_POST){
            try {
            $this->objUsuario = new User();
            $this->objUsuario->setUsername($_POST['username']);
            $this->objUsuario->setEmail($_POST['email']);
            $this->objUsuario->setPassword(md5($_POST['password']));
            $this->objUsuario->setIdRol(3);
            $this->objUsuario->setNombres($_POST['nombres']);
            $this->objUsuario->setApellidos($_POST['apellidos']);
            $this->objUsuario->setEstado(1);
            $respuesta = $this->model->store($this->objUsuario);
            $this->validaciones->usuarioExistente($respuesta);

            $mail = new EnvioCorreo();
            $from = "ocornejo@macrogramec.com";
            $modeloCorreo = new ModelosCorreo();
            $tipo = "Cuenta creada";
            $diseno = $modeloCorreo->registroUsuario($this->objUsuario->getNombres(),$this->objUsuario->getApellidos(),$this->objUsuario->getUsername());
            $validar = $mail->enviarEmail("",$from , $this->objUsuario->getEmail(), $diseno,  $tipo);
            $this->validaciones->validarMail($validar);
            $arrResponse = array('status' => true, 'msg' => 'Registrado', 'title' => 'Correcto','icon'=>'success');
            } catch (Exception $e) {
                $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' =>'error');
            }
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
            }
        die();
    }

}