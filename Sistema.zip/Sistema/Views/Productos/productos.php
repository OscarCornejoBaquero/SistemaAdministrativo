<?php
headers($data);
//getModal('crearCategoria',$data);
?>

<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"> Productos /</span> <?php echo $data['tag_page']?></h4>

    <!-- Basic Bootstrap Table -->
    <div class="card">
        <div class="row">
            <div class="col-9 card-header">
                <h5 class="card-header" ><?php echo $data['tag_page'] ?></h5>
            </div>

            <div class="col-sm-12 col-lg-3  card-header">
                <a type="button" class="btn btn-outline-warning " href="<?php echo base_url()?>productos/create"  style="color: black" title="Agregar Producto">
                    <span class="tf-icons bx bx-plus" ></span>&nbsp; Productos
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive ">
                <table class="table table-striped" id="tableProductos">
                    <thead>
                    <tr>
                        <th>VER</th>
                        <th>CÓDIGO PRODUCTO</th>
                        <th>CATEGORIA</th>
                        <th>STOCK</th>
                        <th>PRECIO UNITARIO</th>
                        <th>IVA </th>
                        <th>ESTADO</th>
                        <th>OPCIONES</th>
                    </tr>
                    </thead>
                    <tbody >

                    </tbody>
                </table>
            </div>
        </div>
    </div>


</div>


<?php
scripts($data);
?>
<script src="<?php echo media()?>/js/web/productos.js"></script>
<?php
fin();
?>
