<?php
require_once ("Objetos/Login/User.php");
class RegistroModel extends Mysql
{
    private User $objUsuario;
    public function __construct()
    {
        parent::__construct();
    }

    public function store(User $objUser){
        $this->objUsuario = $objUser;
        $sql = "call validarUsuarioRegistro('{$this->objUsuario->getUsername()}',
                                            '{$this->objUsuario->getEmail()}') ";
        $request = $this->select($sql);
        if(empty($request)){
                $sql = "call insertUser(?, ?, ?, ?,?,?)";
                $arrData = array($this->objUsuario->getUsername(), $this->objUsuario->getEmail(),
                                 $this->objUsuario->getPassword(),$this->objUsuario->getIdRol(),
                                 $this->objUsuario->getNombres(), $this->objUsuario->getApellidos());
                $request_insert = $this->insert($sql,$arrData);
                $return = $request_insert;
            }else{
                $return = "exist";
        }
        return  $return;
    }
}