<?php require_once("footer.php");?>
<div class="content-backdrop fade"></div>
</div>
</div>
</div>
<div class="layout-overlay layout-menu-toggle"></div>
</div>

<script src="<?php echo media()?>/vendor/libs/jquery/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script src="<?php echo media()?>vendor/libs/popper/popper.js"></script>
<script src="<?php echo media()?>/vendor/js/bootstrap.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo media()?>/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="<?php echo media()?>/vendor/js/menu.js"></script>
<script src="<?php echo media()?>/vendor/libs/apex-charts/apexcharts.js"></script>
<script src="<?php echo media()?>/js/main.js"></script>
<script src="<?php echo media()?>/js/dashboards-analytics.js"></script>
<script async defer src="https://buttons.github.io/buttons.js"></script>

<script src="<?php echo media()?>/js/web/perfil.js"></script>
<script src="<?php echo media()?>vendor/js/jquery.dataTables.js"></script>
<script src="<?php echo media()?>vendor/js/datatables-bootstrap5.js"></script>
<script src="<?php echo media()?>vendor/js/datatables.responsive.js"></script>
<script src="<?php echo media()?>vendor/js/responsive.bootstrap5.js"></script>
<script src="<?php echo media()?>vendor/js/datatables.checkboxes.js"></script>
<script src="<?php echo media()?>vendor/js/datatables-buttons.js"></script>
<script src="<?php echo media()?>vendor/js/buttons.bootstrap5.js"></script>




<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.25/b-1.7.1/b-colvis-1.7.1/b-html5-1.7.1/b-print-1.7.1/date-1.1.0/datatables.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('.js-example-basic-single').select2(
            {
                width: '100%',
                placeholder: "Seleccionar"
            }
        );

    });

    $(document).ready(function(){
        $("#empresa").change(function(){
            var idEmpresa= $(this).children("option:selected").val();
            $.ajax({
                type: "GET",
                url: ""+base_url+"dashboard/cambioEmpresa/"+idEmpresa,
                beforeSend: function(){
                },
                success: function(data){
                    var objData = JSON.parse(data);
                    console.log(objData);
                    location.reload();
                },
                error: function(data){
                    Swal.fire({
                        title: 'Error',
                        text: 'Problemas al cargar los datos de las Ciudades',
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        location.reload();
                    })
                }
            });
        });
    });
</script>