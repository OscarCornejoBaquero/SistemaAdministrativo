<?php
require_once ("Objetos/Empresa/Empresa.php");
class ExEmpresa extends Controllers
{
    private Empresa $objEmpresa;
    public $mensaje;
    public function __construct()
    {
        parent::__construct();
    }
    public function update($request_user){
        if($request_user == 'fallo'){
            throw new Exception('ERROR LA EMPRESA SELECCIONADA TIENE UN PROBLEMA AL ACTUALIZAR INTENTELO MAS TARDE.');
        }
        return true;
    }
    public function store($request_user){
        if($request_user == 'Empresa Existe'){
            throw new Exception('ERROR AL MOMENTO DE CREAR LA EMPRESA. !YA EXISTE');
        }
        return true;
    }
}