<?php
require_once("Models/NavModel.php");
require_once ("Excepciones/ExEmpresa.php");
require_once ("Objetos/Empresa/Empresa.php");
class Informacion extends Controllers
{
    private Empresa $objEmpresa;
    private ExEmpresa $validaciones ;
    public function __construct()
    {
        session_start();
        if (empty($_SESSION['login'])) {
            header('Location: ' . base_url());
        }
        parent::__construct();
         $this->validaciones = new ExEmpresa();
    }
    public function empresas()
    {
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();

        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['tag_page'] = "Información Empresas";
        $data['page_title'] = "Información Empresarial";
        $data['page_name'] = "Información Empresas";
        $this->views->getView($this, "empresas", $data);
    }
    public function getAll()
    {
        $arrData = $this->model->selectAllEmpresas($_SESSION['id_user']);


        for ($i = 0; $i < sizeof($arrData); $i++) {

            $datos = $arrData[$i]['id_empresa'];
            $arrData[$i]['id_empresa'] = '<button class="btn p-0 dropdown-toggle hide-arrow" onclick="openModal(' . $datos . ');" title="Ver Información de la Empresa"><i class="menu-icon tf-icons bx bx-show"></i></button>';
            if ($arrData[$i]['estado'] == 1) {
                $arrData[$i]['estado'] = '<span class="badge badge-success" style="background: green">Activo</span>';
            } else {
                $arrData[$i]['estado'] = '<span class="badge badge-danger" style="background: red">Inactivo</span>';
            }
            $arrData[$i]['acciones'] = '
            <a class="dropdown-item " href="'.base_url().'/establecimiento/establecimientosEmpresas/'.$datos.'" 
                                ><i class="bx bx-add-to-queue me-1"></i> Establecimientos</a
                                >
            ';

            $arrData[$i]['options'] = '
            <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu">
                                
                                <a class="dropdown-item" href="'.base_url().'informacion/editarEmpresa/'.$datos.'"
                                ><i class="bx bx-edit-alt me-1"></i> Editar</a
                                >
                                <a class="dropdown-item " href="#" onclick="eliminar('.$datos.');"
                                ><i class="bx bx-trash me-1"></i> Eliminar</a
                                >
                            </div>
                        </div>
            ';
        }

        echo json_encode($arrData, JSON_UNESCAPED_UNICODE);
        die();
    }
    public function crearEmpresa(){
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();

        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['contribuyentes'] = $this->model->getTipoContribuyente();
        $data['tag_page'] = "Agregar Empresa";
        $data['page_title'] = "Agregar información empresa";
        $data['page_name'] = "Agregar Empresa";
        $this->views->getView($this, "crearEmpresa", $data);
    }
    public function storeEmpresa(){
        if($_POST){
            try {
                $this->objEmpresa = new Empresa();
                $this->objEmpresa->setRuc($_POST['ruc_empresa']);
                $this->objEmpresa->setRazonSocial($_POST['razon_social_empresa']);
                $this->objEmpresa->setNombreComercial($_POST['nombre_comerial_empresa']);
                $this->objEmpresa->setCorreo($_POST['correo_empresa']);
                $this->objEmpresa->setTelefono($_POST['telefono_empresa']);
                $this->objEmpresa->setTipoContribuyente($_POST['descripcion_tipo']);
                $this->objEmpresa->setDireccion($_POST['direccion_empresa']);
                $this->objEmpresa->setIdUser($_SESSION['id_user']);
                if(isset($_POST['lleva_contabilidad'])){
                    $this->objEmpresa->setLlevaContabilidad("SI");
                }else{
                    $this->objEmpresa->setLlevaContabilidad("NO");
                }
                if(isset($_POST['estado'])){
                    $this->objEmpresa->setEstado(1);
                }else{
                    $this->objEmpresa->setEstado(0);
                }

                $this->objEmpresa->setAgenteRetencion($_POST['agente_retencion']);
                $this->objEmpresa->setContribuyenteEspecial($_POST['contribuyente_especial']);
                $this->objEmpresa->setCodigoArtesano($_POST['codigo_artesano']);
                $this->objEmpresa->setNombreRecibos($_POST['nombre_recibos']);
                $this->objEmpresa->setPassFirma($_POST['pass_firma_electronica']);
                //$this->objEmpresa->setFirma($_POST['url_archivo_firma']);
                $newName="";
                $archivo = $_FILES['upload']['name'];
                if (isset($archivo) && $archivo != "") {
                    $array = explode('.', $_FILES['upload']['name']);
                    $tipo = end($array);
                    $newName = "logo" . $this->objEmpresa->getRuc() .'.'. $tipo;
                    if(move_uploaded_file($_FILES["upload"]["tmp_name"], $_SERVER['DOCUMENT_ROOT']."/facturero/Assets/img/empresas/logos/" . $newName)){
                        // $this->objEmpresa->setUrlFoto($newName);
                    }
                }
                $this->objEmpresa->setLogo("$newName");
                //Carga de Firma Electronica
                $archivo = $_FILES['url_archivo_firma']['name'];
                if (isset($archivo) && $archivo != "") {
                    $array = explode('.', $_FILES['url_archivo_firma']['name']);
                    $tipo = end($array);
                    $newName = $this->objEmpresa->getRazonSocial() ." " . $this->objEmpresa->getRuc() .'.'. $tipo;
                    if(move_uploaded_file($_FILES["url_archivo_firma"]["tmp_name"], $_SERVER['DOCUMENT_ROOT']."/facturero/Assets/img/empresas/firmaElectronica/" . $newName)){
                        // $this->objEmpresa->($newName);
                    }
                }
                $this->objEmpresa->setFirma("$newName");



                $respuesta = $this->model->storeEmpresa($this->objEmpresa);
                $this->validaciones->store($respuesta);

                $arrResponse = array('status' => true, 'msg' => 'Empresa Creada Correctamente', 'title' => 'Correcto','icon'=>'success');
            } catch (Exception $e) {
                $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' =>'error');
            }
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
        }
        die();
    }

    public function getInfoEmpresa($id)
    {
        try {
            $respuesta = $this->model->getInformacionEmpresa($id);
            $arrResponse = array('status' => true, 'msg' => 'Usuario Encontrado Bienvenido',
                'title' => 'Correcto', 'icon' => 'success', 'data' => $respuesta);

        } catch (Exception $e) {
            $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' => 'error');
        }
        echo json_encode($arrResponse, JSON_UNESCAPED_UNICODE);
}
    public function editarEmpresa($id)
    {
        $nav = new navModel();
        $arrData = $nav->getMenusPadres();
        $arrDataM = $nav->getMenusHijos();
        $idEmpresa = $id;
        $data['menu_padre'] = $arrData;
        $data['menu_hijos'] = $arrDataM;
        $data['menus'] = $arrData;
        $data['empresa'] = $this->model->getInformacionEmpresa($idEmpresa);
        $data['contribuyentes'] = $this->model->getTipoContribuyente();
        $data['tag_page'] = "Editar Empresa";
        $data['page_title'] = "Editar información empresa";
        $data['page_name'] = "Editar Empresa";
        $this->views->getView($this, "editarEmpresa", $data);
    }
    public function updateEmpresa(){
        if($_POST){
            try {
                $this->objEmpresa = new Empresa();
                $this->objEmpresa->setIdEmpresa($_POST['idEmpresa']);
                $this->objEmpresa->setRuc($_POST['ruc_empresa']);
                $this->objEmpresa->setRazonSocial($_POST['razon_social_empresa']);
                $this->objEmpresa->setNombreComercial($_POST['nombre_comerial_empresa']);
                $this->objEmpresa->setCorreo($_POST['correo_empresa']);
                $this->objEmpresa->setTelefono($_POST['telefono_empresa']);
                $this->objEmpresa->setTipoContribuyente($_POST['descripcion_tipo']);
                $this->objEmpresa->setDireccion($_POST['direccion_empresa']);
                if(isset($_POST['lleva_contabilidad'])){
                    $this->objEmpresa->setLlevaContabilidad("SI");
                }else{
                    $this->objEmpresa->setLlevaContabilidad("NO");
                }
                if(isset($_POST['estado'])){
                    $this->objEmpresa->setEstado(1);
                }else{
                    $this->objEmpresa->setEstado(0);
                }

                $this->objEmpresa->setAgenteRetencion($_POST['agente_retencion']);
                $this->objEmpresa->setContribuyenteEspecial($_POST['contribuyente_especial']);
                $this->objEmpresa->setCodigoArtesano($_POST['codigo_artesano']);
                $this->objEmpresa->setNombreRecibos($_POST['nombre_recibos']);
                $this->objEmpresa->setPassFirma($_POST['pass_firma_electronica']);
                //$this->objEmpresa->setFirma($_POST['url_archivo_firma']);
                $newName="";
                $archivo = $_FILES['upload']['name'];
                if (isset($archivo) && $archivo != "") {
                    $array = explode('.', $_FILES['upload']['name']);
                    $tipo = end($array);
                    $newName = "logo" . $this->objEmpresa->getRuc() .'.'. $tipo;
                    if(move_uploaded_file($_FILES["upload"]["tmp_name"], $_SERVER['DOCUMENT_ROOT']."/facturero/Assets/img/empresas/logos/" . $newName)){
                       // $this->objEmpresa->setUrlFoto($newName);
                    }
                }
                $this->objEmpresa->setLogo("$newName");
                //Carga de Firma Electronica
                $archivo = $_FILES['url_archivo_firma']['name'];
                if (isset($archivo) && $archivo != "") {
                    $array = explode('.', $_FILES['url_archivo_firma']['name']);
                    $tipo = end($array);
                    $newName = $this->objEmpresa->getRazonSocial() ." " . $this->objEmpresa->getRuc() .'.'. $tipo;
                    if(move_uploaded_file($_FILES["url_archivo_firma"]["tmp_name"], $_SERVER['DOCUMENT_ROOT']."/facturero/Assets/img/empresas/firmaElectronica/" . $newName)){
                       // $this->objEmpresa->($newName);
                    }
                }
                $this->objEmpresa->setFirma("$newName");



                $respuesta = $this->model->updateEmpresa($this->objEmpresa);
                $this->validaciones->update($respuesta);

                $arrResponse = array('status' => true, 'msg' => 'Actualizado Correctamente', 'title' => 'Correcto','icon'=>'success');
            } catch (Exception $e) {
                $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' =>'error');
            }
            echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
        }
        die();
    }
    public function eliminarEmpresa($id){
        try {
            $respuesta = $this->model->eliminarEmpresa($id);
            $arrResponse = array('status' => true, 'msg' => 'Empresa Eliminada de Forma Correcta',
                'title' => 'Correcto', 'icon' => 'success', 'data' => $respuesta);

        } catch (Exception $e) {
            $arrResponse = array('status' => false, 'msg' => $e->getMessage(), 'title' => 'Error', 'icon' => 'error');
        }
        echo json_encode($arrResponse, JSON_UNESCAPED_UNICODE);
    }
}