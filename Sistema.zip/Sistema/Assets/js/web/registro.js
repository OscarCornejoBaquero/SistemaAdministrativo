

$(document).ready(function () {
    $('#terms-conditions').on('change', function() {
        self = $(this);
        // validamos que este checked
        if(self.is(':checked')){
            $('#btn-enviar').removeAttr("disabled");
        }else{
            $('#btn-enviar').attr("disabled","disabled");
        }

    });
    $("#formAuthentication").bind("submit",function(e){
        if (validarRegistro()) {
            e.preventDefault();
            Swal.fire({
                title: 'Error en datos del Usuario ',
                text: 'Debe de Ingresar datos para el registro',
                icon: 'error',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
            }).then((result) => {
                location.reload();
            })
        }else{
            // Capturamnos el boton de envío
            var btnEnviar = $("#btn-enviar");
            $.ajax({
                type: $(this).attr("method"),
                url: $(this).attr("action"),
                data:$(this).serialize(),
                beforeSend: function(){
                    /*
                    * Esta función se ejecuta durante el envió de la petición al
                    * servidor.
                    * */
                    btnEnviar.val("Enviando"); // Para input de tipo button
                    btnEnviar.attr("disabled","disabled");
                },
                complete:function(data){
                    /*
                    * Se ejecuta al termino de la petición
                    * */
                    btnEnviar.val("Enviar formulario");
                    btnEnviar.removeAttr("disabled");
                },
                success: function(data){
                    /*
                    * Se ejecuta cuando termina la petición y esta ha sido
                    * correcta
                    * */
                    var objData = JSON.parse(data);
                    var respuesta = objData.msg;
                    var title = objData.title;
                    var icon = objData.icon;
                    console.log(objData.msg);
                    Swal.fire({
                        title: title,
                        text: respuesta,
                        icon: icon,
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        if(title != "Error"){
                            window.location.href = '../../facturero/login'
                        }else{
                            location.reload();
                        }

                    })
                },
                error: function(data){
                    /*
                    * Se ejecuta si la peticón ha sido erronea
                    * */
                    Swal.fire({
                        title: 'Error',
                        text: 'Problemas al tratar de enviar el formulario',
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                    }).then((result) => {
                        location.reload();
                    })
                }
            });
        }
        // Nos permite cancelar el envio del formulario
        return false;
    });

    function validarRegistro(){
        var pass = $('#password').val();
        var user = $('#username').val();
        var email = $('#email').val();
        var nombres = $('#nombres').val();
        var apellidos = $('#apellidos').val();
        if( $('#terms-conditions').prop('checked') ) {
            if (user == "" || pass == "" || email == "" || nombres == "" || apellidos == "") {
                return true;
            }else{
                return false;
            }
        }else{
            return true;
        }

    }
});
