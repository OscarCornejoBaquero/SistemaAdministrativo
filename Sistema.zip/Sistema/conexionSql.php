<?php
if (!isset($_SESSION)) {
    // session_start();
}
//session_start();
ob_start();
//error_reporting(E_ALL);

function fecha()
{
    date_default_timezone_set('America/Guayaquil');
    $time = time();
    $fecha = date("Y-m-d", $time); //FECHA Y HORA ACTUAL
    return $fecha;
}

function noCache()
{
    header("Expires: Tue, 01 Jul 2001 06:00:00 GMT");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
}

function conectarSql()
{
    try {

        //MACROBILLING
        $server = "107.180.75.55\SQLEXPRESS";
        $db = "FACTURERO_MACRO";
        $user = "sa";
        $pass = "+-*MACROadmin";

        $cadena = "Driver={SQL Server}; Server=" . $server . ";Database=" . $db . ";";
        include "administrador/adodb5/adodb.inc.php";
        $conexion = ADONewConnection("odbc_mssql");
        $conexion->Connect($cadena, $user, $pass);
        return $conexion;
    } catch (Exception $e) {
        echo 'Excepción capturada: '. $e->getMessage();
        return false;
    }
}

function Execute($conexion, $query)
{
    $conexion->setFetchMode(ADODB_FETCH_BOTH);
    $result = $conexion->Execute($query);
    if ($result) {
        $array = formatearArray($result->GetArray());
        return $array;
    } else {
        return $conexion->errorMsg();
    }
}



function utf8_encode_array($array)
{
    return array_map('utf8_encode', $array);
}

function formatearArray($array_)
{
    $array = array_map('utf8_encode_array', $array_);
    return $array;
}

function Execute2($conexion, $query)
{
    $result = $conexion->Execute($query);

    $ope = false;
    if (($result->EOF)) {
        $ope = true;
    }

    return $ope;
}

ob_end_flush();
